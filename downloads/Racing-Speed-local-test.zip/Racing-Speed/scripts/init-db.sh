#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
# .env is user-created and trusted shell syntax with random hex values.
set -a
source .env
set +a
[[ "$DB_APP_PASSWORD" =~ ^[a-fA-F0-9]{32,}$ ]] || { echo 'DB_APP_PASSWORD must be at least 32 hex characters'; exit 1; }
docker compose exec -T db psql -U migration_owner -d racing_speed -v ON_ERROR_STOP=1 <<SQL
SELECT 'CREATE ROLE racing_api LOGIN NOSUPERUSER NOBYPASSRLS PASSWORD ''$DB_APP_PASSWORD'''
WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='racing_api')\gexec
GRANT USAGE ON SCHEMA public TO racing_api;
GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO racing_api;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO racing_api;
REVOKE UPDATE,DELETE ON audit_events,custody_ledger_entries,receipt_confirmations,adjustments FROM racing_api;
ALTER DEFAULT PRIVILEGES FOR ROLE migration_owner IN SCHEMA public GRANT SELECT,INSERT,UPDATE,DELETE ON TABLES TO racing_api;
ALTER DEFAULT PRIVILEGES FOR ROLE migration_owner IN SCHEMA public GRANT USAGE,SELECT ON SEQUENCES TO racing_api;
SQL
