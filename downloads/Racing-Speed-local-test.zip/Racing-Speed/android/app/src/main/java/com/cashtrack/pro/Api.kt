package com.cashtrack.pro

import android.util.Base64
import androidx.fragment.app.FragmentActivity
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.IntegrityTokenRequest
import com.google.gson.JsonObject
import java.net.URI
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.CertificatePinner
import okhttp3.ConnectionSpec
import okhttp3.OkHttpClient
import okhttp3.TlsVersion
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

fun obj(vararg values: Pair<String, Any?>): JsonObject =
    JsonObject().apply {
        values.forEach { (k, v) ->
            when (v) {
                null -> add(k, null)
                is String -> addProperty(k, v)
                is Boolean -> addProperty(k, v)
                is Number -> addProperty(k, v)
                is com.google.gson.JsonElement -> add(k, v)
                else -> error("Unsupported field")
            }
        }
    }

interface Api {
    @POST
    suspend fun post(
        @Url path: String,
        @Body body: JsonObject,
        @Header("Authorization") auth: String? = null,
    ): JsonObject

    @GET suspend fun get(@Url path: String, @Header("Authorization") auth: String): JsonObject

    @POST
    suspend fun export(
        @Url path: String,
        @Body body: JsonObject,
        @Header("Authorization") auth: String,
    ): okhttp3.ResponseBody
}

class Repository(private val url: String = BuildConfig.API_BASE_URL) {
    private val client =
        OkHttpClient.Builder()
            .connectionSpecs(
                listOf(
                    ConnectionSpec.Builder(ConnectionSpec.MODERN_TLS)
                        .tlsVersions(TlsVersion.TLS_1_3)
                        .build()
                )
            )
            .followRedirects(false)
            .followSslRedirects(false)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .apply {
                require(url.startsWith("https://")) { "HTTPS required" }
                if (BuildConfig.TLS_PIN.isNotBlank())
                    certificatePinner(
                        CertificatePinner.Builder().add(URI(url).host, BuildConfig.TLS_PIN).build()
                    )
                else check(BuildConfig.DEBUG) { "Release certificate pin must be configured" }
            }
            .build()
    val api: Api =
        Retrofit.Builder()
            .baseUrl(url)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(Api::class.java)
    var access = ""
    private var refresh = ""

    fun clear() {
        access = ""
        refresh = ""
    }

    private fun tokens(r: JsonObject) {
        access = r["accessToken"].asString
        refresh = r["refreshToken"].asString
    }

    suspend fun login(
        user: String,
        device: String,
        pin: String,
        activity: FragmentActivity,
        security: DeviceSecurity,
    ) {
        val payload = obj("userId" to user, "deviceId" to device)
        val challenge =
            api.post(
                "v1/auth/challenge",
                obj(
                    "userId" to user,
                    "deviceId" to device,
                    "action" to "LOGIN",
                    "payload" to payload,
                ),
            )
        val proof = proof(challenge, pin, activity, security)
        tokens(
            api.post("v1/auth/login", obj("userId" to user, "deviceId" to device, "proof" to proof))
        )
    }

    private suspend fun <T> authorized(block: suspend (String) -> T): T {
        try {
            return block("Bearer $access")
        } catch (e: retrofit2.HttpException) {
            if (e.code() != 401 || refresh.isBlank()) throw e
            tokens(api.post("v1/auth/refresh", obj("refreshToken" to refresh)))
            return block("Bearer $access")
        }
    }

    suspend fun get(path: String): JsonObject = authorized { api.get(path, it) }

    private suspend fun proof(
        ch: JsonObject,
        pin: String,
        activity: FragmentActivity,
        security: DeviceSecurity,
    ): JsonObject {
        val message = ch["message"].asString
        val signature = security.sign(activity, message)
        val result = obj("challengeId" to ch["id"].asString, "pin" to pin, "signature" to signature)
        if (!BuildConfig.DEBUG) {
            val nonce =
                Base64.encodeToString(
                    MessageDigest.getInstance("SHA-256").digest(message.toByteArray()),
                    Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING,
                )
            val integrity =
                suspendCancellableCoroutine<String> { c ->
                    IntegrityManagerFactory.create(activity)
                        .requestIntegrityToken(
                            IntegrityTokenRequest.builder().setNonce(nonce).build()
                        )
                        .addOnSuccessListener { if (c.isActive) c.resume(it.token()) }
                        .addOnFailureListener { if (c.isActive) c.resumeWithException(it) }
                }
            result.addProperty("integrityToken", integrity)
        }
        return result
    }

    suspend fun mutate(
        path: String,
        action: String,
        data: JsonObject,
        pin: String,
        activity: FragmentActivity,
        security: DeviceSecurity,
        key: String,
        reference: String? = null,
    ): JsonObject {
        val payload = data.deepCopy()
        if (reference != null) payload.addProperty("id", reference)
        val ch = authorized {
            api.post("v1/challenge", obj("action" to action, "payload" to payload), it)
        }
        val body = obj("key" to key, "data" to data, "proof" to proof(ch, pin, activity, security))
        return authorized { api.post(path, body, it) }
    }

    suspend fun admin(
        data: JsonObject,
        pin: String,
        activity: FragmentActivity,
        security: DeviceSecurity,
    ): JsonObject {
        val ch = authorized {
            api.post("v1/challenge", obj("action" to "ADMIN", "payload" to data), it)
        }
        val p = proof(ch, pin, activity, security)
        return authorized { api.post("v1/admin", obj("data" to data, "proof" to p), it) }
    }

    suspend fun export(
        department: String,
        pin: String,
        activity: FragmentActivity,
        security: DeviceSecurity,
    ): String {
        val ch = authorized {
            api.post(
                "v1/challenge",
                obj("action" to "EXPORT", "payload" to obj("departmentId" to department)),
                it,
            )
        }
        val b = obj("proof" to proof(ch, pin, activity, security))
        return authorized {
            api.export("v1/departments/$department/export", b, it).use { r -> r.string() }
        }
    }
}
