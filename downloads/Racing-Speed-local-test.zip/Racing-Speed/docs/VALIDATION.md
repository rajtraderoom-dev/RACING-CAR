# Validation record

Date: 12 November 2026. Native Android source was built using JDK 17, Gradle 8.13, Android SDK 35 / build-tools 35. PostgreSQL 17 ran in an isolated local container. Backend tests used an actual **NOSUPERUSER NOBYPASSRLS** PostgreSQL runtime login, not an in-memory mock or the database superuser.

## Backend

`npm run build` completed successfully. The automated suite covers:

1. Collector service read denial for records, dashboard, audit, chain and attachments.
2. HOD service department isolation.
3. Sender cannot accept own handover.
4. Concurrent duplicate collections commit once and bind idempotency body.
5. Competing reservations cannot exceed available custody.
6. Three collector hops conserve income; approval requires confirmed HOD custody; approved collection cannot update/delete.
7. Partial/combined handovers and duplicate receipt delivery transfer exactly once.
8. Count mismatch blocks funds with no automatic custody movement; explicit HOD recount resolution.
9. Rejection leaves confirmed custody in place.
10. Cancellation releases reservation without movement.
11. PIN + device signature, challenge replay, amount substitution and refresh rotation.
12. Append-only ledger and audit SQL protections.
13. Direct HTTP collector denial for financial reads, exports and attachment IDs.
14. Direct HTTP HOD department isolation and permitted dashboard retrieval.
15. Task/status response minimization.
16. Unauthenticated requests, absent customer/search routes and no-store headers.
17. PostgreSQL RLS independently hides another department under the constrained role.
18. Production rejects unverified hardware even when the development bypass flag is set.
19. Failed PIN attempts commit and lock out independently of financial transactions.
20. Department audit digest validation and altered-event detection.
21. Unsigned garbage proofs cannot exhaust another account’s PIN attempts.

The raw successful test output is delivered as `backend-tests.txt`. `npm audit --omit=dev` reported zero known vulnerabilities at the time of the run. This registry check is not a source/security review or a guarantee of absence of vulnerabilities.

The Alpine backend container was built successfully and passed a full HTTP smoke flow against PostgreSQL: signed PIN login, new collection, two-sided receipt, HOD approval, and collector ledger denial. The local Caddy route was verified with TLS 1.3 only and CA validation enabled; an unauthenticated request correctly returned 401. Compose configuration validation also passed.

## Android

Two Robolectric UI smoke tests passed on API 35: locked sign-in does not expose the dashboard, and the explicitly marked sample preview navigates to Pit Stop. These JVM tests do not exercise biometric hardware or SQLCipher native opening.

Android lint completed with **0 errors and 17 warnings** (dependency updates, style and obsolete resource qualifiers). The APK signature verification passed with APK Signature Scheme v2; the application label is Racing Speed, package `com.cashtrack.pro.debug`, target SDK 35.

The debug APK is signed using a disposable standard Android debug key. No private signing key is delivered. Android lint is run with errors enabled and no baseline suppressing errors. Dependency-update and style recommendations are documented in the lint report; no certification is inferred. `assembleDebug`, `lintDebug`, `testDebugUnitTest`, and `assembleRelease` all completed successfully. The unsigned release variant exercised R8 shrinking/obfuscation, but an owner-signed, pinned, Play-recognized production release must be built using the README steps.

No physical Android device, biometric sensor, or hardware-backed Android emulator is attached (`/dev/kvm` is unavailable). This session therefore does **not** establish that biometric hardware enrollment, key invalidation, SQLCipher runtime opening, camera/receipt workflows, actual device rendering, large fonts, or 60-fps performance have passed. Compilation and static lint do not replace those tests. No live Google Play Integrity or AWS KMS/S3 credentials were available; production adapter calls are unverified against those services. Production enrollment remains intentionally blocked until hardware attestation evidence verification is implemented and reviewed.

The supplied logo was adapted with image generation for a square icon/splash asset; it is an adaptation, not an exact byte-for-byte copy or a traced vector. The editable SVG container embeds the raster artwork. The earlier unused flat vector concept is separately identified.

## Required next acceptance pass

Use a dedicated physical test phone per role/account or isolated Android profiles. Configure local HTTPS and enroll test keys/users. Perform collection → partial handover → another collector → HOD receipt → approval. Repeat with mismatch, dispute, cancellation, rejected approval and a post-approval adjustment. Interrupt network after submission and verify same-key retry returns the same reference. Confirm collector UI shows no records, totals or export entry points. Change biometrics and confirm the signing key fails closed and revocation/re-enrollment is required. Verify background/idle lock and screen-capture restriction on real devices. Perform independent MASVS-L2 and backend authorization reviews before live cash.
