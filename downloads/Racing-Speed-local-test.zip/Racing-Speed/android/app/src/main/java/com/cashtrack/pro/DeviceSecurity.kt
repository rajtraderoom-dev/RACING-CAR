package com.cashtrack.pro

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.io.File
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

class DeviceSecurity {
    private val alias = "racing-device-v1"
    private val store by lazy { KeyStore.getInstance("AndroidKeyStore").apply { load(null) } }

    fun enrolled() = store.containsAlias(alias)

    fun publicKey(): String {
        val encoded = store.getCertificate(alias).publicKey.encoded
        return "-----BEGIN PUBLIC KEY-----\n" +
            Base64.encodeToString(encoded, Base64.NO_WRAP).chunked(64).joinToString("\n") +
            "\n-----END PUBLIC KEY-----"
    }

    fun enroll(): String {
        check(!enrolled()) {
            "Key already enrolled. Re-enrollment requires administrator revocation."
        }
        val generator = KeyPairGenerator.getInstance("EC", "AndroidKeyStore")
        generator.initialize(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN)
                .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                .setDigests(KeyProperties.DIGEST_SHA256)
                .setUserAuthenticationRequired(true)
                .setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
                .setInvalidatedByBiometricEnrollment(true)
                .build()
        )
        generator.generateKeyPair()
        return publicKey()
    }

    suspend fun sign(activity: FragmentActivity, message: String): String =
        suspendCancellableCoroutine { continuation ->
            try {
                check(
                    BiometricManager.from(activity)
                        .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
                        BiometricManager.BIOMETRIC_SUCCESS
                ) {
                    "Strong biometric required"
                }
                val signer = Signature.getInstance("SHA256withECDSA")
                signer.initSign(store.getKey(alias, null) as PrivateKey)
                val prompt =
                    BiometricPrompt(
                        activity,
                        ContextCompat.getMainExecutor(activity),
                        object : BiometricPrompt.AuthenticationCallback() {
                            override fun onAuthenticationSucceeded(
                                result: BiometricPrompt.AuthenticationResult
                            ) {
                                try {
                                    val s =
                                        result.cryptoObject?.signature ?: error("Missing signature")
                                    s.update(message.toByteArray())
                                    if (continuation.isActive)
                                        continuation.resume(
                                            Base64.encodeToString(s.sign(), Base64.NO_WRAP)
                                        )
                                } catch (e: Exception) {
                                    if (continuation.isActive) continuation.resumeWithException(e)
                                }
                            }

                            override fun onAuthenticationError(code: Int, message: CharSequence) {
                                if (continuation.isActive)
                                    continuation.resumeWithException(
                                        IllegalStateException(
                                            "Biometric authentication cancelled or unavailable"
                                        )
                                    )
                            }
                        },
                    )
                continuation.invokeOnCancellation { prompt.cancelAuthentication() }
                prompt.authenticate(
                    BiometricPrompt.PromptInfo.Builder()
                        .setTitle("Confirm secure action")
                        .setSubtitle("Verify physical cash before confirming")
                        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                        .setNegativeButtonText("Cancel")
                        .build(),
                    BiometricPrompt.CryptoObject(signer),
                )
            } catch (e: Exception) {
                if (continuation.isActive)
                    continuation.resumeWithException(
                        IllegalStateException(
                            "Device key unavailable. Ask your administrator to revoke the device and re-enrol PIN and biometrics.",
                            e,
                        )
                    )
            }
        }

    fun suspicious(): Boolean =
        Build.TAGS?.contains("test-keys") == true ||
            listOf("/system/xbin/su", "/system/bin/su", "/sbin/su").any { File(it).exists() }
}
