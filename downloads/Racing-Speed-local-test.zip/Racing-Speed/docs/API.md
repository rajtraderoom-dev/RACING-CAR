# API contract

Machine-readable OpenAPI 3.1 is in `api/openapi.json`. All paths start with `/v1`. Every financial read has a manager check and department scope; collector task/status endpoints intentionally use different reduced DTOs. There is no generic ORM query, customer-search, notification-history, unauthenticated receipt or sync endpoint.

Amounts are decimal **string paise**, e.g. `"500000"` = ₹5,000. Never submit `5000.0`. IDs and idempotency keys are UUIDs. POST mutations use `{ "key": "uuid", "data": {...}, "proof": {...} }`, except auth, export, admin and attachment upload, whose schemas are explicit in OpenAPI. HOD rejection/discrepancy and receiver dispute/rejection require a reason of 8–1,000 trimmed characters.

## Authentication and signing

1. Operator enrolls the public device key and account PIN hash. Mobile never receives the PIN hash or cloud/database credentials.
2. Request `POST /auth/challenge` with user/device IDs, `action=LOGIN`, and `payload={userId,deviceId}`. Only enrolled active device/account combinations receive a challenge.
3. Response includes `id`, `nonce`, `payloadHash`, `message` and 60-second expiry. Message is UTF-8:

   `cashtrack:v1:<challengeUUID>:<base64urlNonce>:<ACTION>:<hexPayloadSHA256>`

4. Authenticate with `BiometricPrompt` using an initialized `SHA256withECDSA` CryptoObject bound to the enrolled Keystore key. Sign the exact message bytes. Send `proof={challengeId,pin,signature}` to `/auth/login` alongside user/device IDs. `signature` is ordinary Base64 DER ECDSA. Production additionally requires `integrityToken` from Play Integrity with nonce `base64url(SHA256(message))`.
5. Receive a 120-second JWT and opaque 7-day-session refresh token. Keep them only in process memory. On rotation, the old refresh hash is recorded; reuse revokes its session. Role/device/session status is checked from DB for every request. JWT has fixed issuer/audience and HS256 algorithm restriction.
6. For each sensitive action, request authenticated `POST /challenge` with `{action,payload}`. Then submit the mutation with a **fresh** PIN and biometric signature. PIN/signature checks are mandatory on the server; no client boolean substitutes for them. Challenge creation never bypasses endpoint authorization.

Canonical payload uses recursively sorted object keys, JSON string/boolean/null encoding, and arrays in original order. No whitespace is added. Money is strings. Examples:

| Action | Challenge payload |
|---|---|
| COLLECT | `{customerName,amount}` exactly as submitted data |
| HANDOVER | `{receiverId,allocations:[{collectionId,amount},...]}` |
| RECEIPT | `{id:<handover UUID>,actual,decision,reason?}` |
| CANCEL | `{id:<handover UUID>}` |
| REVIEW | `{id:<collection UUID>,decision,reason?}` |
| RESOLVE | `{id:<discrepancy UUID>,resolution,reason}` |
| ADJUST | `{id:<collection UUID>,delta,reason}` |
| EXPORT | `{departmentId:<department UUID>}` |
| ADMIN | Entire submitted `data` object (including initial new-user PIN); never audit/log PIN |
| ATTACHMENT | `{id:<collection UUID>,sha256:hex(SHA256(canonical-base64-content))}` |

For attachment signing, decode input Base64 to bytes and re-encode standard Base64 without whitespace, then SHA-256 that Base64 text. This exact encoding is used by the server, rather than hashing raw bytes; stored attachment integrity separately uses SHA-256 of the actual file bytes. Only managers can attach/retrieve photos. A transaction rollback after an S3 upload can leave a private orphan; lifecycle reconciliation must clean it.

## Custody example

```json
{
  "key": "GENERATED-IDEMPOTENCY-UUID",
  "data": {
    "receiverId": "RECEIVER-UUID",
    "allocations": [
      {"collectionId": "COLLECTION-A-UUID", "amount": "100000"},
      {"collectionId": "COLLECTION-B-UUID", "amount": "50000"}
    ]
  },
  "proof": {
    "challengeId": "CHALLENGE-UUID",
    "pin": "FRESH-PIN",
    "signature": "BASE64-DER-SIGNATURE"
  }
}
```

Initiation returns `{reference,status:"PENDING_RECEIPT"}` with no balances. Receiver submits actual `"150000"`, not an assumed expected amount. A matching accept moves the explicitly allocated custody atomically. Another actual amount opens a discrepancy and blocks all allocations in that handover. `REJECT` is for declining physical receipt; it releases reservations without moving custody. `DISPUTE` records count evidence and blocks funds even if the entered amount matches.

## Read/export limits and errors

Records/audit UI endpoints return latest 500 rows. Dashboard trends cover 30 days, with daily totals using India business-day boundaries. The report endpoint exports all department collections up to 100,000 rows; it refuses larger reports, rather than silently truncating. This package does not yet include date-range/paginated archival reporting. CSV contains only UUID, amount paise and state to prevent formula injection and avoid unnecessary customer PII. No direct bucket URLs are returned to collectors or clients.

Errors are sanitized: 400 validation/configuration, 401 authentication/proof/integrity, 403 role/department, 404 inaccessible reference, 409 funds/state/idempotency conflict, 429 rate limit. Responses use `Cache-Control: no-store`. Default per-instance rate limit is 120 requests per IP per minute with `Retry-After`; deploy a distributed ingress limit before multiple replicas. IDs/statuses can be retried safely with the same idempotency key and a newly authenticated proof; a key is permanently bound to actor/action/body.
