#!/usr/bin/env python3
"""Create local-only secrets; never overwrite existing configuration."""
from pathlib import Path
import secrets
root=Path(__file__).resolve().parent.parent
if (root/'.env').exists() or (root/'backend/.env').exists():raise SystemExit('Configuration exists. Keep it or move it aside explicitly.')
owner,app,jwt=[secrets.token_hex(32) for _ in range(3)]
for path,body in [(root/'.env',f'DB_OWNER_PASSWORD={owner}\nDB_APP_PASSWORD={app}\nJWT_SECRET={jwt}\n'),(root/'backend/.env',f'DATABASE_URL=postgres://migration_owner:{owner}@127.0.0.1:5433/racing_speed\nJWT_SECRET={jwt}\nNODE_ENV=development\nALLOW_UNATTESTED_DEV=true\n')]:
 path.write_text(body);path.chmod(0o600)
print('Local secrets created in .env and backend/.env (mode 0600).')
