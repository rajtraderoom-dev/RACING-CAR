# Racing interface and screen list

**Brand:** Racing Speed. The supplied “RACING CAR GAME” artwork is retained in a square adaptation, used in adaptive launcher layers, splash and sign-in. `assets/play-store-512.png` is 512×512. The supplied detailed raster is not misrepresented as editable vector paths; `assets/logo.svg` wraps the raster, and `assets/alternative-vector-icon.xml` preserves the earlier unused simple vector concept.

**Visual system:** #0B0D10 carbon background, #14181E cards, subtle #282E36 borders, racing red #FF1E1E, electric cyan #00E5FF, approval lime #39FF14 and pending amber #FFB300. Bundled OFL Rajdhani Bold headings use italic motorsport treatment, with Android system sans body for legibility. Cards have generous spacing and rounded corners. Every colour status also has text. No external font fetch is needed. Compose animates the main gauge; demo route animation is decorative, not evidence of a real transfer.

| Screen | User | Content / behavior |
|---|---|---|
| Secure sign-in | All accounts | Brand art, account ID, enrolled-device ID, PIN, strong biometric. Debug-only test server URL and marked sample preview. |
| Device setup | Unauthenticated | Generate/view public key for operator enrollment; no access is granted by this screen. |
| Driver Cockpit | Collector | Three large actions: Start Collection, Handover, Incoming; reference/status lookup; unsynced draft references. No totals, ledger, history, leaderboard or customer list. |
| New Collection | Collector | Customer name and physically received amount; PIN/biometric submit; encrypted Not synced draft option. Fields disappear after submission. |
| Handover | Collector | Enter receiver ID and explicit collection-reference allocations; add several allocations; confirm with PIN/biometric. No suggested balances. |
| Incoming | Collector | References for addressed pending tasks, actual physical count, accept/dispute/reject with required reason and fresh proof. |
| Race Control | HOD / Super Admin | Large daily-target speedometer, approved RPM bars, collector-custody fuel bar, dispute/overdue flags, confirmed-to-HOD Pit Lane ranking and 30-day collection trend. Super Admin enters a department ID to switch scope. |
| Pit Stop | HOD / Super Admin | Department pending records, amount, customer and state; open custody chain. HOD can confirm incoming physical cash. Final approval is HOD-only. |
| Custody Chain | HOD / Super Admin | Chronological confirmed custody ledger; expected vs original actual receipt amounts; discrepancy list; HOD resolution and approve/reject/discrepancy actions, each with fresh PIN/biometric. |
| Live Track | HOD / Super Admin | Track motif and department collection references; open a reference for real events. Demo animation is explicitly illustrative. Live data refreshes on demand. |
| Race Settings | HOD / Super Admin | Department audit viewer, lock, device-enrollment explanation. Super Admin can configure department target/hop/overdue rules, create users, or revoke users. |
| Secure Export | HOD / Super Admin | Confirm fresh PIN and biometric; Android document picker saves CSV. No collector export entry point. |

Money inputs display rupees; exact conversion to paise happens before API submission. Notifications/logs do not contain amounts. FLAG_SECURE applies to the entire activity, including previews; screen capture and recent-app snapshots are restricted by Android. Idle lock is two minutes, with immediate background lock. Offline drafts are the only encrypted financial cache; dashboard/ledger data stays in memory. Rendering/performance and large-font accessibility need physical-device review before release. No 60-fps measurement is claimed.
