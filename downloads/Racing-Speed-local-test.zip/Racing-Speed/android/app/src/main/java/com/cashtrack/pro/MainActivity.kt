package com.cashtrack.pro

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.FragmentActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : FragmentActivity() {
    private val vm: RaceViewModel by viewModels()
    private var pendingExport: String? = null
    private val saveExport =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
            val data = pendingExport
            pendingExport = null
            if (uri != null && data != null)
                contentResolver.openOutputStream(uri)?.use { it.write(data.toByteArray()) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE,
        )
        setContent {
            RacingTheme {
                RacingAppUi(vm, this) { csv ->
                    pendingExport = csv
                    saveExport.launch("racing-speed-report.csv")
                }
            }
        }
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        vm.activity()
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) vm.lock()
    }
}
