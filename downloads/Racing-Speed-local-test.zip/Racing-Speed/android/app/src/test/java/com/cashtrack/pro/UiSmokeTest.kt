package com.cashtrack.pro

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = RacingApp::class)
class UiSmokeTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()

    @Test
    fun appStartsLockedAndDoesNotExposeCashRecords() {
        compose.onNodeWithText("WELCOME TO\nRACE CONTROL").assertExists()
        compose.onNode(hasScrollToIndexAction()).performScrollToNode(hasText("SECURE SIGN IN"))
        compose.onNodeWithText("SECURE SIGN IN").assertExists()
        compose.onNodeWithText("RACE CONTROL").assertDoesNotExist()
        compose.onNodeWithText("PIT LANE").assertDoesNotExist()
        compose.onNodeWithText("LOCAL TEST BUILD · USE TEST CASH ONLY").assertExists()
    }

    @Test
    fun designPreviewIsMarkedAsSampleAndCanOpenPitStop() {
        compose
            .onNode(hasScrollToIndexAction())
            .performScrollToNode(hasText("PREVIEW RACE CONTROL · SAMPLE DATA"))
        compose.onNodeWithText("PREVIEW RACE CONTROL · SAMPLE DATA").performClick()
        compose.onNodeWithText("DESIGN PREVIEW · SAMPLE DATA · NO LIVE CASH").assertExists()
        compose.onNodeWithText("RACE CONTROL").assertExists()
        compose.onNodeWithText("Pit Stop").performClick()
        compose.onNodeWithText("PIT STOP").assertExists()
    }
}
