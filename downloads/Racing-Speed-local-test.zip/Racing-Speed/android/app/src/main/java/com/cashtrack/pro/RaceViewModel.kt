package com.cashtrack.pro

import android.app.Application
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.JsonObject
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class RaceState(
    val role: String = "",
    val department: String = "",
    val busy: Boolean = false,
    val message: String = "",
    val page: String = "home",
    val dashboard: JsonObject? = null,
    val records: List<JsonObject> = emptyList(),
    val tasks: List<String> = emptyList(),
    val result: String = "",
    val audit: List<JsonObject> = emptyList(),
    val chain: JsonObject? = null,
    val demo: Boolean = false,
    val drafts: List<CollectionDraft> = emptyList(),
)

@HiltViewModel
class RaceViewModel @Inject constructor(app: Application) : AndroidViewModel(app) {
    val security = DeviceSecurity()
    private val vault = Vault(app)
    private val database = lazy { DraftDb.open(app) }
    private val db
        get() = database.value

    private var repository: Repository? = null
    var serverUrl = vault.read("test-server") ?: BuildConfig.API_BASE_URL
        private set

    fun testServer(url: String) {
        if (BuildConfig.DEBUG) {
            require(url.startsWith("https://"))
            serverUrl = url.trim().trimEnd('/') + "/"
            vault.write("test-server", serverUrl)
            repository?.clear()
            repository = null
        }
    }

    private val repo
        get() =
            repository
                ?: Repository(if (BuildConfig.DEBUG) serverUrl else BuildConfig.API_BASE_URL).also {
                    repository = it
                }

    private val mutable = MutableStateFlow(RaceState())
    val state = mutable.asStateFlow()
    var userId = vault.read("user") ?: ""
        private set

    var deviceId = vault.read("device") ?: ""
        private set

    private var taskJob: Job? = null
    private var draftJob: Job? = null
    private var idleJob: Job? = null

    fun activity() {
        idleJob?.cancel()
        if (mutable.value.role.isNotBlank())
            idleJob =
                viewModelScope.launch {
                    delay(120000)
                    lock()
                }
    }

    fun lock() {
        taskJob?.cancel()
        repository?.clear()
        draftJob?.cancel()
        idleJob?.cancel()
        mutable.value = RaceState(message = "Locked. Authenticate to continue.")
    }

    fun dismiss() {
        mutable.value = mutable.value.copy(message = "", result = "")
    }

    fun page(value: String) {
        mutable.value = mutable.value.copy(page = value, chain = null)
        activity()
    }

    private fun work(block: suspend () -> Unit) {
        if (mutable.value.busy) return
        mutable.value = mutable.value.copy(busy = true, message = "")
        taskJob =
            viewModelScope.launch {
                try {
                    block()
                } catch (e: Exception) {
                    if (e is kotlinx.coroutines.CancellationException) throw e
                    val msg =
                        when (e) {
                            is retrofit2.HttpException ->
                                when (e.code()) {
                                    401 ->
                                        "Authentication expired or failed. Check PIN and device enrollment."
                                    403 -> "This action is not permitted for your account."
                                    409 ->
                                        "Cash is reserved, disputed, or already processed. Refresh before retrying."
                                    else -> "Request could not be completed (${e.code()})."
                                }
                            is java.io.IOException ->
                                "Connection unavailable. Save new collections as encrypted drafts; handovers require a connection."
                            else -> e.message ?: "Action failed"
                        }
                    mutable.value = mutable.value.copy(message = msg)
                } finally {
                    mutable.value = mutable.value.copy(busy = false)
                }
            }
    }

    fun enrollment(): String = if (security.enrolled()) security.publicKey() else security.enroll()

    fun login(user: String, device: String, pin: String, host: FragmentActivity) = work {
        check(BuildConfig.DEBUG || !security.suspicious()) { "Device security check failed" }
        repo.login(user.trim(), device.trim(), pin, host, security)
        val me = repo.get("v1/me")
        userId = user.trim()
        deviceId = device.trim()
        vault.write("user", userId)
        vault.write("device", deviceId)
        val department = me["departmentId"].takeUnless { it.isJsonNull }?.asString ?: ""
        mutable.value = RaceState(role = me["role"].asString, department = department)
        draftJob?.cancel()
        draftJob =
            viewModelScope.launch {
                db.drafts().observe(userId).collect {
                    mutable.value = mutable.value.copy(drafts = it)
                }
            }
        activity()
        refreshData()
    }

    fun demo() {
        check(BuildConfig.DEBUG)
        mutable.value = RaceState(role = "HOD", department = "demo", demo = true)
        activity()
    }

    fun load() = work { refreshData() }

    private suspend fun refreshData() {
        if (mutable.value.demo) return
        val s = mutable.value
        if (s.role == "COLLECTOR") {
            val tasks =
                repo.get("v1/tasks")["tasks"].asJsonArray.map {
                    it.asJsonObject["reference"].asString
                }
            mutable.value = mutable.value.copy(tasks = tasks)
        } else if (s.department.isNotBlank()) {
            val dash = repo.get("v1/departments/${s.department}/dashboard")
            val rows =
                repo
                    .get("v1/departments/${s.department}/collections")["collections"]
                    .asJsonArray
                    .map { it.asJsonObject }
            mutable.value = mutable.value.copy(dashboard = dash, records = rows)
        }
    }

    fun department(id: String) {
        mutable.value = mutable.value.copy(department = id)
        load()
    }

    fun chain(id: String) = work {
        check(!mutable.value.demo) { "Sample data: connect an account to review cash." }
        mutable.value =
            mutable.value.copy(chain = repo.get("v1/collections/$id/chain"), page = "chain")
    }

    fun saveDraft(customer: String, amount: String) = work {
        check(mutable.value.role == "COLLECTOR")
        require(customer.isNotBlank())
        require(amount.toLong() > 0)
        db.drafts().save(CollectionDraft(UUID.randomUUID().toString(), userId, customer, amount))
        mutable.value = mutable.value.copy(result = "Draft saved · Not synced", page = "home")
    }

    fun submit(
        path: String,
        action: String,
        data: JsonObject,
        pin: String,
        host: FragmentActivity,
        reference: String? = null,
        draftId: String? = null,
    ) = work {
        check(!mutable.value.demo) { "Sample data: connect an account to submit cash." }
        val identity =
            java.security.MessageDigest.getInstance("SHA-256")
                .digest("$userId|$action|$path|$data".toByteArray())
                .joinToString("") { "%02x".format(it) }
        val key =
            vault.read("pending-$identity")
                ?: (draftId ?: UUID.randomUUID().toString()).also {
                    vault.write("pending-$identity", it)
                }
        val response = repo.mutate(path, action, data, pin, host, security, key, reference)
        vault.remove("pending-$identity")
        if (draftId != null) db.drafts().remove(draftId, userId)
        mutable.value =
            mutable.value.copy(
                result = "${response["reference"].asString}\n${response["status"].asString}",
                page = "home",
            )
        activity()
    }

    fun status(ref: String) = work {
        val r = repo.get("v1/status/$ref")
        mutable.value =
            mutable.value.copy(result = "${r["reference"].asString}\n${r["status"].asString}")
    }

    fun audit() = work {
        check(!mutable.value.demo)
        val r = repo.get("v1/departments/${mutable.value.department}/audit")
        mutable.value =
            mutable.value.copy(
                audit = r.getAsJsonArray("events").map { it.asJsonObject },
                page = "audit",
            )
    }

    fun admin(data: JsonObject, pin: String, host: FragmentActivity) = work {
        check(mutable.value.role == "SUPER_ADMIN")
        repo.admin(data, pin, host, security)
        mutable.value = mutable.value.copy(result = "Settings saved", page = "home")
    }

    fun export(pin: String, host: FragmentActivity, onReady: (String) -> Unit) = work {
        check(!mutable.value.demo)
        onReady(repo.export(mutable.value.department, pin, host, security))
    }

    override fun onCleared() {
        if (database.isInitialized()) db.close()
        super.onCleared()
    }
}
