# Racing Speed

Native Android cash-custody app and NestJS/PostgreSQL backend. This records physical cash custody; it does not transfer money. Amounts are integer paise, passed as strings over JSON. This is a local evaluation build, **not production-ready or MASVS certified**.

The name was confirmed as **Racing Speed**. The supplied racing-car artwork was adapted into a square raster launcher/splash asset. Its embedded “RACING CAR GAME” wording is retained as requested. The earlier flat security-logo vector is included as an unused alternative, not a vector recreation of the supplied detailed artwork.

## Included

- `android/`: Kotlin, Compose, Hilt, Flow, Room with SQLCipher, Retrofit/OkHttp, Keystore/BiometricPrompt, SplashScreen API, R8 release configuration, Gradle wrapper.
- `backend/`: NestJS API, PostgreSQL migrations, Argon2id PIN verification, device-signature challenges, short access tokens, rotating refresh tokens, role and department enforcement, transactional custody, append-only ledger/audit, S3/KMS receipt storage adapter.
- `docs/`: permission matrix, threat model, state transitions, API specification, UI description and validation report.
- `assets/`: adapted logo, 512-pixel Play Store icon, SVG source wrapper and optional original vector.
- `compose.yaml`, `Caddyfile.local`, `scripts/`: local testing environment.

Debug builds also allow test/emulator root heuristics to be bypassed; production relies on fail-closed server attestation and integrity.

The debug APK has **Preview Race Control** on the sign-in screen. That preview uses marked sample data and cannot create real cash records. A signed debug APK is for evaluation only. It has user-CA trust and a local HTTPS server setting; these are unavailable in release builds.

## Local setup

Requirements: Docker with Compose, Node 22.21+ (or a maintained newer Node), Python 3, Android SDK 35/build-tools 35, JDK 17+, Android device/API 30+ with a strong biometric. Android Studio can install the SDK and JDK. No test accounts or PINs are shipped.

From this directory:

```bash
python3 scripts/local-env.py
docker compose up -d db
cd backend
npm ci
npm run migrate
cd ..
./scripts/init-db.sh
python3 scripts/use-runtime-db.py
```

The migration owner is used only for schema setup. The script creates `racing_api` with **NOSUPERUSER NOBYPASSRLS**, grants data access, and revokes mutation rights on append-only tables. The generated `backend/.env` is then switched to that runtime account. Migrate again using a separate owner connection when adding migrations; do not grant schema privileges to the runtime role.

Start the backend/TLS proxy:

```bash
docker compose up -d --build api tls
```

The local API is on host loopback `http://127.0.0.1:3000`; Android must use the TLS proxy at `https://10.0.2.2:8443/` (emulator) or `https://localhost:8443/` (USB device with `adb reverse tcp:8443 tcp:8443`). The app's debug login screen lets you enter the test URL.

Export Caddy's local CA certificate:

```bash
docker compose cp tls:/data/caddy/pki/authorities/local/root.crt ./local-test-ca.crt
```

Install **only this local test CA** on the test device through Android Settings → Security → Encryption & credentials → Install CA certificate. For a USB device, run `adb reverse tcp:8443 tcp:8443`. The Compose TLS port binds loopback, so it is not a public deployment. For trusted-LAN tests, deliberately configure a reachable TLS host and firewall instead. Do not turn off TLS verification. Chrome and Android may require importing the CA separately.

The shipped debug APK can be installed with `adb install Racing-Speed-debug.apk` or by opening the APK on your test phone. Allow your file manager to install apps when Android prompts. Do not use this build for live cash.

## Enrol test accounts and devices

1. Open **Set up this device** in the app; enroll a strong biometric in Android Settings first. The app generates a per-use biometric-bound EC signing key and displays its **public key**. The private key stays in Keystore.
2. Create a local mode-0600 JSON file, outside version control, with the fields below. Use the displayed key. Generate UUIDs with `python3 -c 'import uuid; print(uuid.uuid4())'`. All accounts in a department must use the same `departmentId`; there is one HOD per department.
3. From `backend/`, run `npm run provision -- /absolute/path/to/provision-private.json`. Provisioning runs as an owner/operator maintenance action; use your owner DB connection temporarily if runtime grants have been narrowed. It returns account/device/department IDs, never the PIN. Enter these IDs in the app, then authenticate using the chosen PIN and biometric.
4. Create separate collector and HOD accounts on separate enrolled app installations/devices. Creating another Android user/work profile is preferable to sharing credentials. The `admin` API/UI creates accounts, but device enrollment remains an operator-reviewed process.

```json
{
  "userId": "YOUR-UUID",
  "deviceId": "ANOTHER-UUID",
  "departmentId": "SHARED-DEPARTMENT-UUID",
  "departmentName": "Operations",
  "email": "collector@example.test",
  "name": "Test Collector",
  "role": "COLLECTOR",
  "pin": "CHOOSE-6-TO-12-DIGITS",
  "publicKey": "-----BEGIN PUBLIC KEY-----\n...\n-----END PUBLIC KEY-----",
  "attestationReview": "LOCAL DEVELOPMENT ONLY"
}
```

For a Super Admin, set `role` to `SUPER_ADMIN`; its department is automatically null. Do not mark a local device as hardware verified. Production device attestation is a release gate described below.

## Exercise the custody flow

1. Collector creates a collection and notes the returned reference. This is the only new income event.
2. Collector enters a receiver account ID and one or more `(collection reference, amount)` allocations. Partial and combined handovers are supported. No balance or customer search API is available to collectors.
3. Receiver opens Incoming (HOD: Pit Stop → Incoming to HOD), counts physical cash, and enters actual cash received. An exact accepted count atomically moves custody. A mismatch blocks affected allocations; it does not transfer their ledger custody.
4. Repeat collector hops as needed. Department `maxHops=null` means unlimited; a positive number limits collector-to-collector paths. HOD is always the final stop.
5. HOD reviews the chain in Pit Stop, confirms reconciled custody, and approves with fresh PIN and biometric. Rejection changes approval status without reversing custody. Resolve discrepancies explicitly using verified recount/confirmed physical return; no automatic write-off is provided.
6. Approved collection amounts, custody and approval records are immutable. Post-approval corrections are separate audited adjustments via the API; original income remains visible. Corrections are not treated as internal handover income.

## Tests

After migration and `use-runtime-db.py`, from `backend/`:

```bash
npm run build
npm test
```

Use a dedicated test database; tests insert randomly named departments/accounts and retain data for inspection. They must run under the non-superuser runtime account. Test configuration must set `ALLOW_UNATTESTED_DEV=true`, `NODE_ENV=development`, and a random `JWT_SECRET` of 48+ characters; the generated `.env` does so. The suite covers direct HTTP restrictions, PostgreSQL RLS, replay binding, refresh rotation, idempotency, concurrent reservation, partial/combined transfers, multi-hop conservation, mismatches, rejection and approved-record immutability. See `docs/VALIDATION.md` for the actual run and Android test limits.

Verify a departmental audit chain with an authorized owner/operator DB connection:

```bash
npx tsx src/verify-audit.ts DEPARTMENT-UUID
```

Keep the returned hash head in an independent append-only/WORM store. Hash chains detect changes relative to trusted checkpoints; a database superuser who can disable triggers and rewrite backups is outside the protection of an unanchored chain.

## Build Android

```bash
cd android
./gradlew assembleDebug
```

Run `./gradlew testDebugUnitTest lintDebug` for the local UI smoke tests and lint. These tests do not simulate biometric hardware.

The wrapper uses Gradle 8.13. `JAVA_HOME` must point to a full JDK, not just a JRE. If Gradle cannot create its default debug keystore, create a local one:

```bash
mkdir -p keys
keytool -genkeypair -noprompt -keystore keys/debug.keystore \
  -storepass android -keypass android -alias androiddebugkey \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -dname 'CN=Android Debug,O=Android,C=US'
```

These standard Android **debug** credentials do not protect production releases. No signing private keys are included in the source archive.

### Signed release APK

Create a private release keystore outside the repository. Let keytool prompt for passwords; do not commit them or put real passwords in shell history.

```bash
keytool -genkeypair -v -keystore /secure/location/racing-speed.jks \
  -alias racing-speed -keyalg RSA -keysize 3072 -validity 10000
```

Set `RELEASE_STORE_FILE`, `RELEASE_STORE_PASSWORD`, `RELEASE_KEY_ALIAS`, and `RELEASE_KEY_PASSWORD` using your CI secret store or a private local environment. The `release` signingConfig reads those environment variables. Back up the key through your organization's secure process. Configure real API hostname, current SPKI pin and Play Integrity first:

```bash
./gradlew assembleRelease \
  -PapiBaseUrl=https://YOUR-API-HOST/ \
  -PtlsPin='sha256/YOUR-BASE64-SPKI-PIN'
```

Output: `app/build/outputs/apk/release/app-release.apk`. Check it:

```bash
$ANDROID_HOME/build-tools/35.0.0/apksigner verify --verbose --print-certs \
  app/build/outputs/apk/release/app-release.apk
```

The release build uses R8 and blocks repository connections without a configured pin. Distribute through a controlled testing track before rollout. Certificate pins must match your real TLS endpoint; plan key rotation before deployment. Play Integrity cert digest is the **app signing certificate**, not the TLS SPKI pin. Play App Signing may use a different key from your upload key.

## Deployment and release gates

Use PostgreSQL on private networking, separate owner/runtime credentials, encrypted disks and tested backups. Configure backend `NODE_ENV=production`; the development integrity bypass is then ignored. Use a managed secret store, TLS 1.3 ingress (`Caddyfile.production.example`), ingress rate limits across replicas, private bucket policy with SSE-KMS, KMS key permissions scoped to the runtime identity, retention and object lifecycle policies. Supply `AWS_REGION`, `ATTACHMENT_BUCKET`, `ATTACHMENT_KMS_KEY`; use workload identity, not embedded cloud keys. Receipt download is an authenticated API proxy, never a public URL. An orphaned failed-upload object should be removed by lifecycle reconciliation; it never receives an accessible DB reference.

Set `ANDROID_PACKAGE`, `ANDROID_CERT_SHA256` (base64url digest expected by Play Integrity), and Google application-default credentials authorized for the Play Integrity API. Server checks nonce/action binding, package, app recognition, certificate, freshness and `MEETS_STRONG_INTEGRITY`. Release installation must be recognized by Play; side-loaded debug testing uses the explicit development bypass only. These external integrations are implemented but were not tested against live Google/AWS services here.

**Hardware-key attestation enrollment is not automated in this local package.** A security operator must verify Android attestation certificate chain, challenge, verified boot, patch level, hardware security level, public-key binding and per-operation `BIOMETRIC_STRONG` authentication policy before setting a device's `hardware_verified=true`. The current app exports SPKI, not a remote attestation evidence package; therefore production enrollment requires completing an attestation enrollment service/client and its review. Setting a boolean without evidence is not verification. Production proof checks fail closed for unverified devices. Changing biometrics invalidates the signing key; revoke the device/sessions, reset PIN through the verified recovery process, clear local test app data, and enroll again.

Before live cash: complete that enrollment workflow; test BiometricPrompt/Keystore invalidation and SQLCipher on physical devices; verify live Play Integrity and S3/KMS; perform MASVS-L2/authorization review and penetration testing; anchor audit heads externally; test backup restoration, PIN recovery, token revocation and TLS pin rotation. No real customer SMS/WhatsApp sending, push notifications, or gamification awards are enabled. The gamification configuration flag is stored for future award rules; it never exposes collector amounts. Local drafts only: no offline handover or approval. The UI refreshes on demand; it does not claim a live server-push feed or a measured 60-fps guarantee.

Use `docker compose down` to stop local services. Add `-v` only if you deliberately intend to delete test database/TLS volumes.
