# Permission matrix and threat model

This is a local test implementation. Authorization runs on the backend for each call, with PostgreSQL department RLS as an additional barrier. UI role selection is not an authorization source. Roles are loaded from the database for each access-token request. Customers have no account.

| Capability | Super Admin | HOD | Collector | Customer |
|---|---|---|---|---|
| Full collections / customer names / balances / chains | Any department | Own department | Denied | Denied |
| Dashboard / leaderboard amounts / trends | Any department | Own department | Denied | Denied |
| Audit / reports / attachment download | Any department | Own department | Denied | Denied |
| New cash collection | Denied | Denied | Own department; submission only | Denied |
| Initiate / cancel unreceived handover | Denied | Denied | Own available custody / own handover | Denied |
| Accept / dispute / reject incoming | Denied | Addressed to self | Addressed to self | Denied |
| Final approval | Denied | Own department after full reconciliation | Denied | Denied |
| Resolve discrepancies | Denied | Own department, reason + fresh proof | Denied | Denied |
| Post-approval adjustment | All departments, audited | Own department, audited | Denied | Denied |
| Users / departments / policies | Allowed with fresh proof | Denied | Denied | Denied |
| Task reference/status lookup | Involved tasks only | Involved tasks only | Involved tasks only | Denied |
| Offline | No finalization | No finalization | Encrypted unsynced collection drafts only | None |

Collectors cannot list past collections, browse customers, search, export, read attachments, or read another person's balances. Incoming task DTOs contain only a reference and status. Submitted results contain only reference/status. No endpoints broadcast notification bodies, enable arbitrary queries, or expose a general sync feed. Receipt/customer lookup for unauthenticated customers is deliberately absent; optional SMS/WhatsApp receipts are not enabled.

The service database login is trusted code infrastructure; it must not be exposed to mobile clients. It can establish `app.role`/`app.department` inside transactions to perform authorized operations. RLS protects accidental omitted department predicates, not an attacker with arbitrary code execution or stolen runtime database credentials. Collectors have no database login. The runtime account must not be the database owner, a superuser, or BYPASSRLS.

## Trust boundaries

Android UI → HTTPS/TLS 1.3 ingress → NestJS authorization/challenge service → PostgreSQL transaction and RLS → private KMS-encrypted receipt store. Android Keystore gates device signatures; SQLCipher stores only offline drafts. Google Play Integrity is a separate server-verification boundary. Operators enroll verified identities and devices through a controlled channel.

| Threat | Implemented controls | Residual/release requirement |
|---|---|---|
| Collector guesses a ledger/export/attachment ID | Manager guard before query or storage lookup; department guards/RLS; opaque UUIDs | Continue negative tests for every new endpoint |
| HOD guesses another department or reference | Own-department policy in service and DB transaction | Prevent superuser/runtime-role misconfiguration |
| Client changes role / spoofs JWT | HMAC JWT with issuer/audience/algorithm restriction; role fetched from DB; server session/device checks | 48+ random character secret, rotation and secret vault |
| Device theft or PIN guessing | Strong biometric per-use EC key, Argon2id server PIN hash, bounded challenges, account backoff, idle/background lock | Hardware evidence/recovery workflow and physical device tests |
| Replay or amount/receiver substitution | 60-second server nonce; SHA-256 canonical payload; action/reference binding; one-use challenge; signature and PIN required | Verify clock synchronization; monitor failed proofs without logging bodies |
| Duplicate requests / competing senders | Per-user idempotency key and payload hash; sorted row locks; reservation constraints; atomic transactions | Load/fault testing and operational retries; keep idempotency records longer than retry window |
| Sender falsely claims receiver has cash | Submission reserves only; receiver actual count creates receipt; mismatch blocks full affected funds | Physical counts and collusion remain organizational risks |
| Custody multiplied as income | Collection-only income aggregate; internal ledger transfers conserve amounts | Independently reconcile actual bank/physical closeout |
| Silent edits to approved cash | DB triggers protect approved collection/approval/custody/allocation/attachment rows; immutable ledger; adjustment inserts | DB administrators can disable triggers; audit checkpoints/independent review |
| Audit deletion/rewrite | Append-only triggers, chained hashes with per-department locked head | Anchor heads to independent WORM system; restricted DB ops and backups |
| Malicious file / public URL | Manager-only upload, JPEG/PNG signatures, size cap, private S3 key, SSE-KMS; authenticated proxy and SHA-256 validation | Add image decoding/re-encoding, malware scanning and metadata stripping before production receipt ingestion |
| Session/refresh theft | Access token lasts 2 minutes, refresh hashes rotate; old refresh replay revokes session; DB revocation checked per request | Tokens only in mobile process memory; device signatures still required for mutations; refresh family pruning |
| Tampered/rooted app | Local root heuristics; release Play Integrity server validation; R8; secure display flag | Root heuristics are bypassable; live Integrity review and attestation enrollment incomplete |
| Network interception | Platform TLS checks, release SPKI pin, no cleartext; TLS 1.3 proxy example | Real hostname/pins/rotation; debug user-CA trust is only for testing |
| Amounts in logs/notifications | No request-body/access-token logging; sanitized error responses; no push/SMS transport enabled | Infrastructure logs and crash tooling must obey the same redaction rules |
| Backups / local extraction | Android backup disabled; drafts encrypted with SQLCipher and Keystore-sealed passphrase | OS/device compromise; server encrypted volumes and restore drills |

## Device and PIN lifecycle

An SPKI signature proves possession of an enrolled key; without reviewed hardware attestation it does not independently prove a biometric prompt ran. In development, `ALLOW_UNATTESTED_DEV=true` opts into such testing. Production ignores that bypass and demands `hardware_verified` plus Play Integrity. The present client does not upload full attestation evidence, so **production enrollment is blocked until the enrollment service is completed and reviewed**. Never set the verified flag merely to make a login work.

Per-operation biometric keys are invalidated by biometric-enrollment changes. Recovery requires verified identity, device/session revocation, fresh PIN enrollment, and a newly attested key. The local test workflow uses the operator CLI and clearing test app data; self-service PIN recovery is not shipped. Failed login/proof attempts consume challenges and update account backoff in a separate committed transaction, so financial rollback cannot reset counters.

## Audit semantics

Audit chains are independent per department, plus a global chain for cross-department administration. Each digest is `SHA256(previousHash + canonical(event))`. `event` includes UUID, actor ID, role, department, action, before/after data, reason and millisecond UTC timestamp. `audit_heads` serializes writers. Chain validation must use the complete departmental event sequence, not the latest-500 UI slice. Approved source records are never modified by adjustments. No claim of OWASP certification is made; MASVS-L2 is the review target.
