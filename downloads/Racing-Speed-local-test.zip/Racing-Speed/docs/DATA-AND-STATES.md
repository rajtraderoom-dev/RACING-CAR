# Database and transition rules

SQL is in `backend/migrations/001_init.sql` through `003_immutability.sql`. UUIDs are generated on the server. Currency is `bigint` paise and serialized as decimal strings; application arithmetic is `BigInt`. Positive collection/allocation amounts are capped at 9,000,000,000,000,000 paise to keep mobile/JSON representations controlled. Kotlin uses `BigDecimal` only to convert exact user-entered rupees to integer paise; fractional paise are rejected.

Departments own customers, collections, allocations, custody positions, handovers, confirmations, approvals, discrepancies, adjustments, attachments and audit events. User roles are assigned once per account; a Super Admin has null department, and each department has at most one HOD. This local model deliberately uses one active role/department per user; multi-department identities use separate accounts until a reviewed multi-assignment model is added.

`custody_positions` is the locked projection of the immutable ledger. Its primary key is `(collection_id, holder_id)` and it enforces `amount >= 0`, `reserved >= 0`, `blocked >= 0`, `reserved + blocked <= amount`. `available = amount - reserved - blocked` is computed internally, never returned to collectors. The sum of custody amounts across holders equals the original collection. Reservations and blocked amounts are subsets of custody, not new cash.

`cash_collections` is the source of collection income. `custody_ledger_entries` records initial receipt and confirmed internal transfers; do **not** sum all ledger rows as revenue. `adjustments` is a separate audited correction journal for approved source records; corrected income is original income plus explicitly reported adjustments. The current dashboard shows original collection income, not a concealed adjustment net.

Indexes cover department/date, incoming and outgoing pending handovers, open discrepancies, collection chain and audit sequence. Handovers disallow same sender/receiver. Allocation `(handover, collection)` is unique; duplicate source allocations in a request are rejected. A receipt confirmation is unique per handover. Idempotency `(user, key)` stores request digest and committed reference/status; reuse with another body returns 409. Key records should not be purged while a client might retry.

## Transitions

```mermaid
stateDiagram-v2
  [*] --> CREATED
  CREATED --> IN_CUSTODY: collection and initial custody commit together
  IN_CUSTODY --> IN_CUSTODY: partial or collector transfer
  IN_CUSTODY --> HANDED_TO_HOD: all remaining cash is with HOD
  HANDED_TO_HOD --> APPROVED: HOD proof + reconciled custody
  APPROVED --> [*]: immutable; adjustment inserts only
```

`CREATED` is represented in the schema but creation and initial custody happen in one transaction, so no externally observable intermediate row can lack custody.

```mermaid
stateDiagram-v2
  [*] --> INITIATED
  INITIATED --> PENDING_RECEIPT: reserve explicit allocations
  PENDING_RECEIPT --> RECEIVED: receiver count matches
  PENDING_RECEIPT --> DISPUTED: mismatch or explicit dispute
  PENDING_RECEIPT --> REJECTED: receiver declines before receipt
  PENDING_RECEIPT --> CANCELLED: sender cancels before receipt
  DISPUTED --> RECEIVED: HOD confirms full physical recount
  DISPUTED --> REJECTED: HOD confirms physical return
```

Initiation/reservation is one transaction; `INITIATED` is not returned. Receiver rejection releases reservation only, with no custody movement and a mandatory reason. Cancellation is sender-only. An actual-count mismatch creates an immutable original confirmation and an open discrepancy, releases reserved amount into `blocked`, and makes no custody ledger movement. A later recount resolution is a separate audited event; it does not rewrite the original count. A shortage cannot be waved through as reconciled: restore/count the full expected funds, or document confirmed return. A generalized shortage/write-off/insurance settlement workflow is not implemented.

```mermaid
stateDiagram-v2
  [*] --> PENDING_HOD
  PENDING_HOD --> UNDER_REVIEW
  UNDER_REVIEW --> APPROVED
  UNDER_REVIEW --> DISCREPANCY_OPEN
  UNDER_REVIEW --> REJECTED
  DISCREPANCY_OPEN --> PENDING_HOD: explicit verified resolution
  REJECTED --> UNDER_REVIEW: review again; custody unchanged
```

`UNDER_REVIEW` is currently transactional during the HOD decision; no long-running client-held review lock is created. Approval requires HOD ownership of the full original amount, `HANDED_TO_HOD`, no reservations/blocked funds and no open collection/allocated-handover discrepancy. The caller must be the department HOD, not Super Admin or the collection creator. The UI action and server proof are bound to the collection reference and decision.

## Concurrency and rollback

Every financial mutation begins a DB transaction, establishes role/department context and inserts/locks its idempotency record. Initiation locks collections in sorted UUID order before source positions. Receipt locks its handover, then sorted collections, then positions. Approval locks the collection before checking ownership and discrepancies. Transfers debit source and credit destination in the same transaction, append ledger/audit events, then commit the reference/status result. A transaction failure rolls everything back, including reservations and the incomplete idempotency result; the separate authentication attempt remains consumed. No external request can observe half a custody transfer.

Approved records have database triggers rejecting updates/deletes. Append-only ledger, confirmation, adjustment and audit tables reject updates/deletes regardless of approval status. Runtime SQL access is infrastructure-only. An independently controlled read replica/backup and externally anchored audit heads are needed to detect malicious superuser changes.
