#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parent.parent
values=dict(line.split('=',1) for line in (root/'.env').read_text().splitlines() if line and not line.startswith('#'))
p=root/'backend/.env';body=p.read_text().splitlines();body=[f'DATABASE_URL=postgres://racing_api:{values["DB_APP_PASSWORD"]}@127.0.0.1:5433/racing_speed' if line.startswith('DATABASE_URL=') else line for line in body];p.write_text('\n'.join(body)+'\n');p.chmod(0o600)
print('Host backend and tests now use the constrained runtime database role.')
