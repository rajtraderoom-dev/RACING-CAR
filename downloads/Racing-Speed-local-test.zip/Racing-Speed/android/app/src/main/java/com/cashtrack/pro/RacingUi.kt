package com.cashtrack.pro

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.gson.JsonArray
import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.*

val Carbon = Color(0xFF0B0D10)
val Panel = Color(0xFF14181E)
val Line = Color(0xFF282E36)
val Muted = Color(0xFF929CA9)
val Cyan = Color(0xFF00E5FF)
val Red = Color(0xFFFF1E1E)
val Lime = Color(0xFF39FF14)
val Amber = Color(0xFFFFB300)
val RacingFont = FontFamily(Font(R.font.rajdhani_bold))

@Composable
fun RacingTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme =
            darkColorScheme(
                primary = Cyan,
                secondary = Red,
                background = Carbon,
                surface = Panel,
                onBackground = Color.White,
                onSurface = Color.White,
                outline = Line,
            ),
        typography =
            Typography(
                headlineLarge =
                    androidx.compose.ui.text.TextStyle(
                        fontFamily = RacingFont,
                        fontSize = 36.sp,
                        fontStyle = FontStyle.Italic,
                    ),
                titleLarge =
                    androidx.compose.ui.text.TextStyle(fontFamily = RacingFont, fontSize = 24.sp),
            ),
        content = content,
    )
}

fun rupees(paise: String): String =
    try {
        val n = BigDecimal(paise).movePointLeft(2)
        val f = java.text.NumberFormat.getCurrencyInstance(java.util.Locale.forLanguageTag("en-IN"))
        f.format(n)
    } catch (_: Exception) {
        "₹0.00"
    }

fun toPaise(value: String, allowZero: Boolean = false): String =
    try {
        BigDecimal(value)
            .movePointRight(2)
            .setScale(0, RoundingMode.UNNECESSARY)
            .toBigIntegerExact()
            .also {
                require(
                    it.signum() >= (if (allowZero) 0 else 1) &&
                        it <= java.math.BigInteger("9000000000000000")
                )
            }
            .toString()
    } catch (_: Exception) {
        ""
    }

@Composable
fun Heading(text: String, color: Color = Color.White, size: Int = 24) {
    Text(
        text,
        fontFamily = RacingFont,
        fontSize = size.sp,
        fontStyle = FontStyle.Italic,
        color = color,
    )
}

@Composable
fun Tag(text: String, color: Color = Cyan) {
    Text(
        text,
        color = color,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier =
            Modifier.clip(RoundedCornerShape(4.dp))
                .background(color.copy(alpha = .09f))
                .padding(horizontal = 8.dp, vertical = 5.dp),
    )
}

@Composable
fun RaceCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Panel)
            .border(1.dp, Line, RoundedCornerShape(16.dp))
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content,
    )
}

@Composable
fun Field(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    numeric: Boolean = false,
    secret: Boolean = false,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        keyboardOptions =
            KeyboardOptions(
                keyboardType =
                    if (secret) KeyboardType.NumberPassword
                    else if (numeric) KeyboardType.Decimal else KeyboardType.Text
            ),
        visualTransformation =
            if (secret) PasswordVisualTransformation()
            else androidx.compose.ui.text.input.VisualTransformation.None,
        shape = RoundedCornerShape(10.dp),
    )
}

@Composable
fun Action(label: String, onClick: () -> Unit, enabled: Boolean = true, color: Color = Cyan) {
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Carbon),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth().height(52.dp),
    ) {
        Text(label, fontFamily = RacingFont, fontSize = 18.sp)
    }
}

@Composable
fun RacingAppUi(vm: RaceViewModel, host: FragmentActivity, onExport: (String) -> Unit) {
    val s by vm.state.collectAsStateWithLifecycle()
    var exportPrompt by remember { mutableStateOf(false) }
    Scaffold(
        containerColor = Carbon,
        topBar = {
            Column(Modifier.statusBarsPadding().padding(20.dp, 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painterResource(R.drawable.brand_logo),
                        contentDescription = "Racing Speed logo",
                        modifier = Modifier.size(48.dp),
                    )
                    Column(Modifier.weight(1f).padding(start = 10.dp)) {
                        Heading("RACING SPEED", size = 23)
                        Text(
                            "CASH CUSTODY • SECURED",
                            fontSize = 9.sp,
                            color = Muted,
                            letterSpacing = 2.sp,
                        )
                    }
                    if (s.role.isNotBlank() && s.role != "COLLECTOR")
                        IconButton(onClick = { vm.page("settings") }) {
                            Icon(Icons.Outlined.Settings, "Settings", tint = Muted)
                        }
                    if (s.role.isNotBlank())
                        IconButton(onClick = vm::lock) {
                            Icon(Icons.Outlined.Lock, "Lock", tint = Muted)
                        }
                }
                HorizontalDivider(color = Line, modifier = Modifier.padding(top = 12.dp))
            }
        },
        bottomBar = {
            if (s.role.isNotBlank() && s.role != "COLLECTOR")
                NavigationBar(containerColor = Carbon) {
                    listOf(
                            "home" to "Race Control",
                            "approvals" to "Pit Stop",
                            "track" to "Live Track",
                        )
                        .forEachIndexed { index, (page, label) ->
                            NavigationBarItem(
                                selected = s.page == page,
                                onClick = { vm.page(page) },
                                icon = {
                                    Icon(
                                        when (index) {
                                            0 -> Icons.Outlined.Speed
                                            1 -> Icons.Outlined.FactCheck
                                            else -> Icons.Outlined.Route
                                        },
                                        label,
                                    )
                                },
                                label = { Text(label, fontSize = 11.sp) },
                            )
                        }
                }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (s.busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Cyan)
            if (BuildConfig.DEBUG && !s.demo)
                Text(
                    "LOCAL TEST BUILD · USE TEST CASH ONLY",
                    fontSize = 10.sp,
                    color = Amber,
                    modifier =
                        Modifier.fillMaxWidth().background(Amber.copy(alpha = .08f)).padding(8.dp),
                )
            if (s.demo)
                Text(
                    "DESIGN PREVIEW · SAMPLE DATA · NO LIVE CASH",
                    fontSize = 10.sp,
                    color = Amber,
                    modifier =
                        Modifier.fillMaxWidth().background(Amber.copy(alpha = .1f)).padding(10.dp),
                )
            if (s.message.isNotBlank())
                Row(Modifier.fillMaxWidth().background(Red.copy(alpha = .12f)).padding(16.dp)) {
                    Text(
                        s.message,
                        modifier = Modifier.weight(1f),
                        color = Color.White,
                        fontSize = 12.sp,
                    )
                    TextButton(onClick = vm::dismiss) { Text("Dismiss") }
                }
            if (s.result.isNotBlank())
                RaceCard(Modifier.padding(16.dp)) {
                    Tag("REFERENCE / STATUS", Lime)
                    Text(s.result, fontSize = 13.sp)
                    TextButton(onClick = vm::dismiss) { Text("Done") }
                }
            when {
                s.role.isBlank() -> Login(vm, host, s.busy)
                s.role == "COLLECTOR" -> Cockpit(vm, host, s)
                s.page == "settings" -> Settings(vm, host, s)
                s.page == "audit" -> AuditScreen(s)
                s.page == "chain" -> Chain(vm, host, s)
                s.page == "approvals" -> Approvals(vm, s, host)
                s.page == "track" -> Track(vm, s)
                else -> Dashboard(vm, s, { exportPrompt = true })
            }
        }
    }
    if (exportPrompt) {
        var pin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { exportPrompt = false },
            title = { Heading("SECURE EXPORT") },
            text = {
                Column {
                    Text(
                        "Export the latest 500 department records. Your PIN and biometric confirmation are required."
                    )
                    Field("Fresh PIN", pin, { pin = it }, secret = true)
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        exportPrompt = false
                        vm.export(pin, host, onExport)
                        pin = ""
                    }
                ) {
                    Text("Confirm & export")
                }
            },
            dismissButton = { TextButton(onClick = { exportPrompt = false }) { Text("Cancel") } },
        )
    }
}

@Composable
fun Login(vm: RaceViewModel, host: FragmentActivity, busy: Boolean) {
    var server by remember { mutableStateOf(vm.serverUrl) }
    var user by remember { mutableStateOf(vm.userId) }
    var device by remember { mutableStateOf(vm.deviceId) }
    var pin by remember { mutableStateOf("") }
    var enrollment by remember { mutableStateOf("") }
    var localError by remember { mutableStateOf("") }
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
    ) {
        item {
            Image(
                painterResource(R.drawable.brand_logo),
                contentDescription = "Your racing logo",
                modifier = Modifier.fillMaxWidth().height(180.dp),
            )
            Tag("YOUR CASH. EVERY HAND. ACCOUNTED.")
            Heading("WELCOME TO\nRACE CONTROL", size = 40)
            Text(
                "A clear chain of custody. From collection to the finish line.",
                color = Muted,
                fontSize = 14.sp,
            )
        }
        item {
            RaceCard {
                Tag("SECURE SIGN IN")
                if (BuildConfig.DEBUG) Field("Local test server (HTTPS)", server, { server = it })
                Field("Your account ID", user, { user = it })
                Field("Enrolled device ID", device, { device = it })
                Field("App PIN", pin, { pin = it }, secret = true)
                Action(
                    "UNLOCK WITH BIOMETRICS",
                    {
                        val p = pin
                        pin = ""
                        if (BuildConfig.DEBUG) vm.testServer(server)
                        vm.login(user, device, p, host)
                    },
                    !busy &&
                        pin.length >= 6 &&
                        user.isNotBlank() &&
                        device.isNotBlank() &&
                        (!BuildConfig.DEBUG || server.trim().startsWith("https://")),
                )
                Text(
                    "Strong biometric + PIN required. Locks after 2 minutes of inactivity.",
                    color = Muted,
                    fontSize = 11.sp,
                )
            }
        }
        item {
            TextButton(
                onClick = {
                    try {
                        enrollment = vm.enrollment()
                    } catch (e: Exception) {
                        localError = e.message ?: "Enrollment unavailable"
                    }
                }
            ) {
                Text("Set up this device", color = Cyan)
            }
            if (localError.isNotBlank()) Text(localError, color = Amber)
            if (enrollment.isNotBlank()) {
                RaceCard {
                    Heading("DEVICE ENROLLMENT")
                    Text(
                        "Send this public key to your administrator through your approved enrollment process. No account access is granted until the device is verified.",
                        color = Muted,
                        fontSize = 12.sp,
                    )
                    androidx.compose.foundation.text.selection.SelectionContainer {
                        Text(enrollment, fontSize = 10.sp)
                    }
                }
            }
        }
        if (BuildConfig.DEBUG)
            item {
                OutlinedButton(onClick = vm::demo, modifier = Modifier.fillMaxWidth()) {
                    Text("PREVIEW RACE CONTROL · SAMPLE DATA")
                }
            }
    }
}

@Composable
fun Speedometer(collected: String, target: String) {
    val ratio =
        (collected.toDoubleOrNull() ?: 0.0) / (target.toDoubleOrNull()?.coerceAtLeast(1.0) ?: 1.0)
    val progress by
        animateFloatAsState(ratio.toFloat().coerceIn(0f, 1f), tween(1000), label = "daily progress")
    Box(Modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.BottomCenter) {
        Canvas(Modifier.fillMaxSize()) {
            val diameter = min(size.width - 22.dp.toPx(), size.height * 1.5f)
            val left = (size.width - diameter) / 2
            val top = 8.dp.toPx()
            val center = Offset(size.width / 2, top + diameter / 2)
            val radius = diameter / 2
            drawArc(
                Line,
                150f,
                240f,
                false,
                Offset(left, top),
                Size(diameter, diameter),
                style = Stroke(13.dp.toPx(), cap = StrokeCap.Round),
            )
            drawArc(
                Brush.sweepGradient(listOf(Cyan, Cyan, Red, Red, Cyan), center),
                150f,
                240f * progress,
                false,
                Offset(left, top),
                Size(diameter, diameter),
                style = Stroke(13.dp.toPx(), cap = StrokeCap.Round),
            )
            for (i in 0..40) {
                val angle = (150 + i * 6) * PI / 180
                val r = radius - 20.dp.toPx()
                val length = if (i % 5 == 0) 12.dp.toPx() else 5.dp.toPx()
                drawLine(
                    if (i % 5 == 0) Muted else Line,
                    Offset(
                        center.x + cos(angle).toFloat() * r,
                        center.y + sin(angle).toFloat() * r,
                    ),
                    Offset(
                        center.x + cos(angle).toFloat() * (r - length),
                        center.y + sin(angle).toFloat() * (r - length),
                    ),
                    if (i % 5 == 0) 2.dp.toPx() else 1.dp.toPx(),
                )
            }
            val angle = (150 + progress * 240) * PI / 180
            val tip =
                Offset(
                    center.x + cos(angle).toFloat() * (radius - 43.dp.toPx()),
                    center.y + sin(angle).toFloat() * (radius - 43.dp.toPx()),
                )
            drawLine(Red, center, tip, 3.dp.toPx(), StrokeCap.Round)
            drawCircle(Red, 6.dp.toPx(), center)
        }
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(bottom = 4.dp).background(Panel).padding(horizontal = 8.dp),
        ) {
            Text("TODAY’S COLLECTION", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
            Heading(rupees(collected), size = 36)
            Text("TARGET  ${rupees(target)}", color = Muted, fontSize = 10.sp)
            Spacer(Modifier.height(8.dp))
            Tag("${(ratio*100).toInt()}% OF DAILY TARGET", Cyan)
        }
    }
}

@Composable
fun Dashboard(vm: RaceViewModel, s: RaceState, onExport: () -> Unit) {
    val d = s.dashboard
    val collected = if (s.demo) "18450000" else d?.get("collected")?.asString ?: "0"
    val target = if (s.demo) "25000000" else d?.get("target")?.asString ?: "1"
    val approved = if (s.demo) "14200000" else d?.get("approved")?.asString ?: "0"
    val held = if (s.demo) "4250000" else d?.get("held")?.asString ?: "0"
    val ratio =
        (approved.toFloatOrNull() ?: 0f) / (collected.toFloatOrNull()?.coerceAtLeast(1f) ?: 1f)
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "OPERATIONS / TODAY",
                        fontSize = 10.sp,
                        color = Muted,
                        letterSpacing = 2.sp,
                    )
                    Heading("RACE CONTROL", size = 34)
                }
                Tag(if (s.demo) "DEMO" else "LIVE", Lime)
                IconButton(onClick = vm::load) {
                    Icon(Icons.Outlined.Refresh, "Refresh", tint = Muted)
                }
            }
        }
        if (s.role == "SUPER_ADMIN")
            item {
                var department by remember { mutableStateOf(s.department) }
                RaceCard {
                    Field("Department ID", department, { department = it })
                    Action("OPEN DEPARTMENT", { vm.department(department) })
                }
            }
        item {
            RaceCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Tag("DAILY PERFORMANCE")
                    Icon(Icons.Outlined.Speed, null, tint = Cyan, modifier = Modifier.size(20.dp))
                }
                Speedometer(collected, target)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                RaceCard(Modifier.weight(1f)) {
                    Text("CASH APPROVED", color = Muted, fontSize = 10.sp)
                    Heading("${(ratio*100).toInt()}%", Lime, 32)
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        repeat(12) {
                            Box(
                                Modifier.weight(1f)
                                    .height((12 + it * 2).dp)
                                    .background(
                                        if (it < ratio * 12) Lime else Line,
                                        RoundedCornerShape(2.dp),
                                    )
                            )
                        }
                    }
                    Text(rupees(approved), fontSize = 12.sp, color = Muted)
                }
                RaceCard(Modifier.weight(1f)) {
                    Text("IN COLLECTOR CUSTODY", color = Muted, fontSize = 9.sp)
                    Heading(rupees(held), Amber, 25)
                    LinearProgressIndicator(
                        progress = {
                            ((held.toFloatOrNull() ?: 0f) /
                                    (collected.toFloatOrNull()?.coerceAtLeast(1f) ?: 1f))
                                .coerceIn(0f, 1f)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        color = Amber,
                        trackColor = Line,
                    )
                    Text("AWAITING HANDOVER", fontSize = 9.sp, color = Muted)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val issues = if (s.demo) 2 else d?.getAsJsonArray("discrepancies")?.size() ?: 0
                val overdue = if (s.demo) 3 else d?.get("overdue")?.asInt ?: 0
                Tag("⚑ $issues DISPUTED", Red)
                Tag("⚑ $overdue OVERDUE", Amber)
            }
        }
        item {
            RaceCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Heading("PIT LANE")
                    Text("HANDED TO HOD", color = Muted, fontSize = 9.sp)
                }
                val leaders =
                    if (s.demo)
                        listOf(
                            "Arjun Mehta" to "6850000",
                            "Priya Sharma" to "5220000",
                            "Rahul Nair" to "2130000",
                        )
                    else
                        d?.getAsJsonArray("leaderboard")?.map {
                            it.asJsonObject["name"].asString to it.asJsonObject["amount"].asString
                        } ?: emptyList()
                if (leaders.isEmpty()) Text("Confirmed handovers will appear here.", color = Muted)
                leaders.forEachIndexed { index, (name, value) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Heading("P${index+1}", if (index == 0) Cyan else Muted, 26)
                        Column(Modifier.weight(1f).padding(start = 14.dp)) {
                            Text(name, fontSize = 14.sp)
                            Text("CONFIRMED AT FINISH", fontSize = 8.sp, color = Muted)
                        }
                        Text(rupees(value), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            RaceCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Heading("COLLECTION PACE")
                    Tag("30 DAYS", Muted)
                }
                val values =
                    if (s.demo) listOf(20f, 32f, 27f, 54f, 44f, 70f, 61f, 81f)
                    else
                        d?.getAsJsonArray("trend")?.map { it.asJsonObject["amount"].asFloat }
                            ?: listOf(0f)
                Trend(values)
                Text(
                    "Collection income only • internal handovers excluded",
                    fontSize = 9.sp,
                    color = Muted,
                )
            }
        }
        item {
            OutlinedButton(
                onClick = onExport,
                enabled = !s.demo && s.department.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(Icons.Outlined.FileDownload, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("EXPORT DEPARTMENT REPORT")
            }
        }
    }
}

@Composable
fun Trend(values: List<Float>) {
    Canvas(Modifier.fillMaxWidth().height(90.dp)) {
        repeat(4) { i ->
            val y = size.height * i / 3
            drawLine(Line, Offset(0f, y), Offset(size.width, y), 1f)
        }
        val max = values.maxOrNull()?.coerceAtLeast(1f) ?: 1f
        val pts =
            values.mapIndexed { i, v ->
                Offset(
                    i.toFloat() / ((values.size - 1).coerceAtLeast(1)) * size.width,
                    size.height - v / max * size.height * .9f,
                )
            }
        val path = Path()
        pts.forEachIndexed { i, p -> if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y) }
        drawPath(path, Cyan, style = Stroke(2.dp.toPx()))
        pts.lastOrNull()?.let { drawCircle(Cyan, 4.dp.toPx(), it) }
    }
}

@Composable
fun Cockpit(vm: RaceViewModel, host: FragmentActivity, s: RaceState) {
    var customer by remember { mutableStateOf("") }
    var value by remember { mutableStateOf("") }
    var receiver by remember { mutableStateOf("") }
    var ref by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var draftId by remember { mutableStateOf<String?>(null) }
    val allocations = remember { mutableStateListOf<Pair<String, String>>() }
    fun clear() {
        customer = ""
        value = ""
        receiver = ""
        ref = ""
        pin = ""
        reason = ""
        draftId = null
        allocations.clear()
    }
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
    ) {
        item {
            Text(
                "COLLECTOR / SECURE WORKSPACE",
                fontSize = 10.sp,
                color = Muted,
                letterSpacing = 1.sp,
            )
            Heading("DRIVER COCKPIT", size = 34)
            Text("Count. Confirm. Keep cash moving.", color = Muted, fontSize = 13.sp)
        }
        if (s.page == "home") {
            item {
                listOf(
                        Triple("collection", "START COLLECTION", Icons.Outlined.AddCircleOutline),
                        Triple("handover", "HANDOVER", Icons.Outlined.SwapHoriz),
                        Triple("incoming", "INCOMING", Icons.Outlined.MoveToInbox),
                    )
                    .forEachIndexed { i, (page, label, icon) ->
                        RaceCard(
                            Modifier.padding(bottom = 12.dp).clickable {
                                clear()
                                vm.page(page)
                            }
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    icon,
                                    null,
                                    tint = if (i == 0) Cyan else if (i == 1) Red else Amber,
                                    modifier = Modifier.size(34.dp),
                                )
                                Column(Modifier.weight(1f).padding(start = 16.dp)) {
                                    Heading(label, size = 22)
                                    Text(
                                        listOf(
                                            "Record cash received from a customer",
                                            "Pass custody to an authorised receiver",
                                            "Count and confirm incoming cash",
                                        )[i],
                                        color = Muted,
                                        fontSize = 11.sp,
                                    )
                                }
                                Icon(Icons.Outlined.ArrowForward, null, tint = Muted)
                            }
                        }
                    }
            }
            if (s.drafts.isNotEmpty())
                item {
                    Heading("NOT SYNCED", Amber)
                    Text(
                        "Encrypted drafts are stored only on this device. They do not count as collected cash until submitted.",
                        color = Muted,
                        fontSize = 12.sp,
                    )
                }
            items(s.drafts) { draft ->
                RaceCard {
                    Tag("NOT SYNCED", Amber)
                    Text("Draft ${draft.id.take(8)}", fontSize = 12.sp)
                    TextButton(
                        onClick = {
                            customer = draft.customer
                            value = BigDecimal(draft.amount).movePointLeft(2).toPlainString()
                            draftId = draft.id
                            vm.page("collection")
                        }
                    ) {
                        Text("Open draft")
                    }
                }
            }
            item {
                RaceCard {
                    Heading("CHECK A REFERENCE")
                    Field("Reference number", ref, { ref = it })
                    OutlinedButton(onClick = { vm.status(ref) }, enabled = ref.isNotBlank()) {
                        Text("Show status")
                    }
                }
            }
        } else {
            item {
                TextButton(
                    onClick = {
                        clear()
                        vm.page("home")
                    }
                ) {
                    Text("← Back to cockpit")
                }
            }
            when (s.page) {
                "collection" ->
                    item {
                        RaceCard {
                            Heading("NEW COLLECTION")
                            Field("Customer name", customer, { customer = it })
                            Field("Cash received (₹)", value, { value = it }, numeric = true)
                            Field("Fresh app PIN", pin, { pin = it }, secret = true)
                            Action(
                                "CONFIRM CASH RECEIVED",
                                {
                                    val p = pin
                                    pin = ""
                                    vm.submit(
                                        "v1/collections",
                                        "COLLECT",
                                        obj(
                                            "customerName" to customer.trim(),
                                            "amount" to toPaise(value),
                                        ),
                                        p,
                                        host,
                                        draftId = draftId,
                                    )
                                },
                                !s.busy &&
                                    toPaise(value).isNotBlank() &&
                                    customer.isNotBlank() &&
                                    pin.length >= 6,
                            )
                            OutlinedButton(
                                onClick = { vm.saveDraft(customer, toPaise(value)) },
                                enabled = toPaise(value).isNotBlank() && customer.isNotBlank(),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Text("Save encrypted draft · Not synced")
                            }
                        }
                    }
                "handover" ->
                    item {
                        RaceCard {
                            Heading("INITIATE HANDOVER")
                            Text(
                                "Use collection references and explicit amounts. Cash remains your responsibility until the receiver confirms it.",
                                color = Muted,
                                fontSize = 12.sp,
                            )
                            Field("Receiver account ID", receiver, { receiver = it })
                            Field("Collection reference", ref, { ref = it })
                            Field("Allocation (₹)", value, { value = it }, numeric = true)
                            OutlinedButton(
                                onClick = {
                                    allocations.add(ref to toPaise(value))
                                    ref = ""
                                    value = ""
                                },
                                enabled = ref.isNotBlank() && toPaise(value).isNotBlank(),
                            ) {
                                Text("Add allocation")
                            }
                            allocations.forEachIndexed { i, (id, n) ->
                                Row {
                                    Text(
                                        "${id.take(8)}…  ${rupees(n)}",
                                        modifier = Modifier.weight(1f),
                                        fontSize = 12.sp,
                                    )
                                    TextButton(onClick = { allocations.removeAt(i) }) {
                                        Text("Remove")
                                    }
                                }
                            }
                            Field("Fresh app PIN", pin, { pin = it }, secret = true)
                            Action(
                                "RESERVE & REQUEST HANDOVER",
                                {
                                    val ar = JsonArray()
                                    allocations.forEach { (id, n) ->
                                        ar.add(obj("collectionId" to id, "amount" to n))
                                    }
                                    val p = pin
                                    pin = ""
                                    vm.submit(
                                        "v1/handovers",
                                        "HANDOVER",
                                        obj("receiverId" to receiver, "allocations" to ar),
                                        p,
                                        host,
                                    )
                                },
                                !s.busy &&
                                    receiver.isNotBlank() &&
                                    allocations.isNotEmpty() &&
                                    pin.length >= 6,
                                color = Red,
                            )
                        }
                    }
                "incoming" -> {
                    item {
                        RaceCard {
                            Heading("INCOMING TASKS")
                            Text(
                                "Enter the cash you physically counted. Sender submission is not proof of receipt.",
                                color = Muted,
                                fontSize = 12.sp,
                            )
                            OutlinedButton(onClick = vm::load) { Text("Refresh incoming") }
                            s.tasks.forEach { t ->
                                TextButton(onClick = { ref = t }) { Text(t, fontSize = 11.sp) }
                            }
                            Field("Handover reference", ref, { ref = it })
                            Field(
                                "Cash actually counted (₹)",
                                value,
                                { value = it },
                                numeric = true,
                            )
                            Field("Reason for dispute / rejection", reason, { reason = it })
                            Field("Fresh app PIN", pin, { pin = it }, secret = true)
                            val actual =
                                try {
                                    BigDecimal(value)
                                        .movePointRight(2)
                                        .toBigIntegerExact()
                                        .also { require(it.signum() >= 0) }
                                        .toString()
                                } catch (_: Exception) {
                                    ""
                                }
                            Action(
                                "ACCEPT COUNTED CASH",
                                {
                                    val p = pin
                                    pin = ""
                                    vm.submit(
                                        "v1/handovers/$ref/receipt",
                                        "RECEIPT",
                                        obj("actual" to actual, "decision" to "ACCEPT"),
                                        p,
                                        host,
                                        ref,
                                    )
                                },
                                !s.busy &&
                                    ref.isNotBlank() &&
                                    actual.isNotBlank() &&
                                    pin.length >= 6,
                            )
                            Action(
                                "RAISE DISPUTE",
                                {
                                    val p = pin
                                    pin = ""
                                    vm.submit(
                                        "v1/handovers/$ref/receipt",
                                        "RECEIPT",
                                        obj(
                                            "actual" to actual,
                                            "decision" to "DISPUTE",
                                            "reason" to reason,
                                        ),
                                        p,
                                        host,
                                        ref,
                                    )
                                },
                                !s.busy &&
                                    ref.isNotBlank() &&
                                    actual.isNotBlank() &&
                                    pin.length >= 6 &&
                                    reason.length >= 8,
                                color = Amber,
                            )
                            TextButton(
                                onClick = {
                                    val p = pin
                                    pin = ""
                                    vm.submit(
                                        "v1/handovers/$ref/receipt",
                                        "RECEIPT",
                                        obj(
                                            "actual" to "0",
                                            "decision" to "REJECT",
                                            "reason" to reason,
                                        ),
                                        p,
                                        host,
                                        ref,
                                    )
                                },
                                enabled = ref.isNotBlank() && pin.length >= 6 && reason.length >= 8,
                            ) {
                                Text("Reject without receiving", color = Red)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Approvals(vm: RaceViewModel, s: RaceState, host: FragmentActivity) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
    ) {
        item {
            Tag("PHYSICAL CASH VERIFICATION", Amber)
            Heading("PIT STOP", size = 34)
            Text("Review the custody chain before final approval.", color = Muted)
            TextButton(onClick = vm::load) { Text("Refresh queue") }
        }
        if (s.demo)
            items(listOf("RC-2401 • Arjun Mehta", "RC-2402 • Priya Sharma")) { name ->
                RaceCard {
                    Tag("AWAITING HOD", Amber)
                    Heading(name, size = 20)
                    Text("Sample receipt · ₹12,500.00", color = Muted)
                    OutlinedButton(onClick = { vm.chain("demo") }) { Text("Review chain") }
                }
            }
        else {
            val pending = s.records.filter { it["state"].asString != "APPROVED" }
            if (pending.isEmpty())
                item {
                    RaceCard {
                        Icon(Icons.Outlined.CheckCircle, null, tint = Lime)
                        Heading("ALL CLEAR")
                        Text("No collections waiting for review.", color = Muted)
                    }
                }
            items(pending) { r ->
                RaceCard {
                    Tag(r["approval_status"].asString, Amber)
                    Heading(rupees(r["amount"].asString), size = 28)
                    Text(r["customer"].asString, color = Muted)
                    Text(r["id"].asString, fontSize = 10.sp, color = Muted)
                    Action("REVIEW CUSTODY CHAIN", { vm.chain(r["id"].asString) })
                }
            }
        }
        item {
            Heading("INCOMING TO HOD")
            ManagerReceipt(vm, s, host)
        }
    }
}

@Composable
fun ManagerReceipt(vm: RaceViewModel, s: RaceState, host: FragmentActivity) {
    var id by remember { mutableStateOf("") }
    var value by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    RaceCard {
        Text("Confirm physical receipt before approval.", color = Muted, fontSize = 12.sp)
        Field("Handover reference", id, { id = it })
        Field("Cash actually counted (₹)", value, { value = it }, numeric = true)
        Field("Fresh PIN", pin, { pin = it }, secret = true)
        Action(
            "CONFIRM PHYSICAL RECEIPT",
            {
                val p = pin
                pin = ""
                vm.submit(
                    "v1/handovers/$id/receipt",
                    "RECEIPT",
                    obj("actual" to toPaise(value, true), "decision" to "ACCEPT"),
                    p,
                    host,
                    id,
                )
            },
            !s.demo && pin.length >= 6 && toPaise(value, true).isNotBlank() && id.isNotBlank(),
        )
    }
}

@Composable
fun Chain(vm: RaceViewModel, host: FragmentActivity, s: RaceState) {
    val chain = s.chain ?: return
    val col = chain["collection"].asJsonObject
    val id = col["id"].asString
    var reason by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
    ) {
        item {
            TextButton(onClick = { vm.page("approvals") }) { Text("← Back to Pit Stop") }
            Heading("CUSTODY CHAIN")
            Tag(col["state"].asString)
            Heading(rupees(col["amount"].asString), size = 34)
            Text(id, color = Muted, fontSize = 10.sp)
        }
        items(chain["ledger"].asJsonArray.toList()) { e ->
            val l = e.asJsonObject
            RaceCard {
                Text(
                    "${l["from_user"].takeUnless{it.isJsonNull}?.asString?.take(8)?:"CUSTOMER"} → ${l["to_user"].asString.take(8)}",
                    fontFamily = RacingFont,
                    color = Cyan,
                )
                Text(rupees(l["amount"].asString))
                Text(l["created_at"].asString, fontSize = 10.sp, color = Muted)
            }
        }
        items(chain["handovers"].asJsonArray.toList()) { e ->
            val h = e.asJsonObject
            RaceCard {
                Tag(h["state"].asString)
                Text("Expected: ${rupees(h["expected"].asString)}")
                Text(
                    "Counted: ${h["actual"].takeUnless{it.isJsonNull}?.asString?.let{rupees(it)}?:"Not confirmed"}"
                )
                Text(h["id"].asString, fontSize = 10.sp, color = Muted)
            }
        }
        items(chain["discrepancies"].asJsonArray.toList()) { e ->
            val d = e.asJsonObject
            RaceCard {
                Tag(d["state"].asString, Red)
                Text(d["reason"].asString)
                Text(
                    "Expected ${rupees(d["expected"].asString)} · Counted ${rupees(d["actual"].asString)}",
                    color = Muted,
                    fontSize = 12.sp,
                )
                if (d["state"].asString == "OPEN" && s.role == "HOD") {
                    Field("Resolution evidence / reason", reason, { reason = it })
                    Field("Fresh PIN", pin, { pin = it }, secret = true)
                    val handover = d["handover_id"].takeUnless { it.isJsonNull }
                    listOf(
                            if (handover == null) "REVIEW_CLEARED" else "RECOUNT_MATCHED",
                            if (handover == null) "REVIEW_CLEARED" else "RETURN_CONFIRMED",
                        )
                        .distinct()
                        .forEach { resolution ->
                            OutlinedButton(
                                onClick = {
                                    val p = pin
                                    pin = ""
                                    vm.submit(
                                        "v1/discrepancies/${d["id"].asString}/resolve",
                                        "RESOLVE",
                                        obj("resolution" to resolution, "reason" to reason),
                                        p,
                                        host,
                                        d["id"].asString,
                                    )
                                },
                                enabled = reason.length >= 8 && pin.length >= 6,
                            ) {
                                Text(resolution.replace('_', ' '), fontSize = 11.sp)
                            }
                        }
                }
            }
        }
        if (s.role == "HOD" && col["state"].asString != "APPROVED")
            item {
                RaceCard {
                    Heading("HOD VERIFICATION")
                    Text(
                        "Approval confirms the full expected cash is physically in your custody, with no open discrepancies.",
                        color = Muted,
                        fontSize = 12.sp,
                    )
                    Field("Reason (required for rejection / discrepancy)", reason, { reason = it })
                    Field("Fresh app PIN", pin, { pin = it }, secret = true)
                    listOf("APPROVE", "DISCREPANCY", "REJECT").forEach { decision ->
                        Action(
                            decision,
                            {
                                val data = obj("decision" to decision)
                                if (reason.isNotBlank()) data.addProperty("reason", reason)
                                val p = pin
                                pin = ""
                                vm.submit("v1/collections/$id/review", "REVIEW", data, p, host, id)
                            },
                            !s.busy &&
                                pin.length >= 6 &&
                                (decision == "APPROVE" || reason.length >= 8),
                            color =
                                when (decision) {
                                    "APPROVE" -> Lime
                                    "REJECT" -> Red
                                    else -> Amber
                                },
                        )
                    }
                }
            }
    }
}

@Composable
fun Track(vm: RaceViewModel, s: RaceState) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
    ) {
        item {
            Tag("CHAIN OF CUSTODY", Cyan)
            Heading("LIVE TRACK", size = 34)
            Text("Each stop is a confirmed change of custody.", color = Muted)
        }
        item {
            RaceCard {
                val transition = rememberInfiniteTransition(label = "track")
                val position by
                    transition.animateFloat(
                        0f,
                        1f,
                        infiniteRepeatable(tween(5000, easing = LinearEasing)),
                        label = "car",
                    )
                Canvas(Modifier.fillMaxWidth().height(140.dp)) {
                    val r = 48.dp.toPx()
                    drawRoundRect(
                        Line,
                        Offset(4.dp.toPx(), 20.dp.toPx()),
                        Size(size.width - 8.dp.toPx(), 100.dp.toPx()),
                        androidx.compose.ui.geometry.CornerRadius(r, r),
                        style = Stroke(12.dp.toPx()),
                    )
                    drawRoundRect(
                        Muted,
                        Offset(4.dp.toPx(), 20.dp.toPx()),
                        Size(size.width - 8.dp.toPx(), 100.dp.toPx()),
                        androidx.compose.ui.geometry.CornerRadius(r, r),
                        style =
                            Stroke(
                                1.dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f)),
                            ),
                    )
                    if (s.demo)
                        drawCircle(
                            Cyan,
                            6.dp.toPx(),
                            Offset(
                                30.dp.toPx() + position * (size.width - 60.dp.toPx()),
                                20.dp.toPx(),
                            ),
                        )
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("CUSTOMER", fontSize = 9.sp, color = Muted)
                    Text("COLLECTOR(S)", fontSize = 9.sp, color = Cyan)
                    Text("HOD", fontSize = 9.sp, color = Lime)
                }
                Text(
                    if (s.demo) "Illustrative route animation"
                    else "Open a reference for its confirmed custody events.",
                    color = Muted,
                    fontSize = 10.sp,
                )
            }
        }
        items(s.records) { r ->
            RaceCard(Modifier.clickable { vm.chain(r["id"].asString) }) {
                Tag(r["state"].asString, if (r["state"].asString == "APPROVED") Lime else Amber)
                Text(r["id"].asString, fontSize = 11.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(r["collector"].asString, color = Muted, fontSize = 12.sp)
                    Text(rupees(r["amount"].asString), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun Settings(vm: RaceViewModel, host: FragmentActivity, s: RaceState) {
    var mode by remember { mutableStateOf("DEPARTMENT") }
    var id by remember { mutableStateOf(java.util.UUID.randomUUID().toString()) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var department by remember { mutableStateOf(s.department) }
    var role by remember { mutableStateOf("COLLECTOR") }
    var newPin by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("100000") }
    var hops by remember { mutableStateOf("") }
    var overdue by remember { mutableStateOf("120") }
    var badges by remember { mutableStateOf(false) }
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
    ) {
        item {
            Heading("RACE SETTINGS", size = 34)
            Tag(s.role)
            Text(
                "This app locks automatically after 2 minutes of inactivity and whenever you leave it.",
                color = Muted,
                fontSize = 12.sp,
            )
            OutlinedButton(onClick = vm::audit, enabled = !s.demo && s.department.isNotBlank()) {
                Text("View department audit log")
            }
        }
        if (s.role == "SUPER_ADMIN") {
            item {
                RaceCard {
                    Heading("MANAGE OPERATIONS")
                    Row {
                        listOf("DEPARTMENT", "USER", "REVOKE").forEach { v ->
                            FilterChip(
                                selected = mode == v,
                                onClick = {
                                    mode = v
                                    id = java.util.UUID.randomUUID().toString()
                                },
                                label = { Text(v, fontSize = 10.sp) },
                                modifier = Modifier.padding(end = 4.dp),
                            )
                        }
                    }
                    Field(
                        if (mode == "REVOKE") "Account ID to revoke" else "Reference ID",
                        id,
                        { id = it },
                    )
                    if (mode != "REVOKE") Field("Name", name, { name = it })
                    if (mode == "DEPARTMENT") {
                        Field(
                            "Daily collection target (₹)",
                            target,
                            { target = it },
                            numeric = true,
                        )
                        Field(
                            "Collector hop limit (blank = unlimited)",
                            hops,
                            { hops = it },
                            numeric = true,
                        )
                        Field(
                            "Overdue alert after minutes",
                            overdue,
                            { overdue = it },
                            numeric = true,
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = badges, onCheckedChange = { badges = it })
                            Text("Enable on-time handover badges", fontSize = 12.sp)
                        }
                    } else if (mode == "USER") {
                        Field("Email", email, { email = it })
                        Field("Department ID", department, { department = it })
                        Row {
                            listOf("COLLECTOR", "HOD", "SUPER_ADMIN").forEach { v ->
                                FilterChip(
                                    selected = role == v,
                                    onClick = { role = v },
                                    label = { Text(v, fontSize = 8.sp) },
                                    modifier = Modifier.padding(end = 3.dp),
                                )
                            }
                        }
                        Field("Initial app PIN", newPin, { newPin = it }, secret = true)
                    }
                    Field("Your fresh admin PIN", pin, { pin = it }, secret = true)
                    Action(
                        "VERIFY & SAVE",
                        {
                            val data =
                                when (mode) {
                                    "DEPARTMENT" ->
                                        obj(
                                            "operation" to mode,
                                            "id" to id,
                                            "name" to name,
                                            "dailyTarget" to toPaise(target),
                                            "maxHops" to hops.toIntOrNull(),
                                            "overdueMinutes" to (overdue.toIntOrNull() ?: 120),
                                            "gamification" to badges,
                                        )
                                    "USER" ->
                                        obj(
                                            "operation" to mode,
                                            "id" to id,
                                            "email" to email,
                                            "name" to name,
                                            "pin" to newPin,
                                            "role" to role,
                                            "departmentId" to
                                                if (role == "SUPER_ADMIN") null else department,
                                        )
                                    else -> obj("operation" to mode, "userId" to id)
                                }
                            val p = pin
                            pin = ""
                            newPin = ""
                            vm.admin(data, p, host)
                        },
                        !s.demo && pin.length >= 6,
                    )
                }
            }
        }
        item {
            RaceCard {
                Heading("DEVICE SECURITY")
                Text(
                    "Changing enrolled biometrics invalidates this device’s signing key. Your administrator must revoke the old device and complete fresh PIN and device enrollment.",
                    color = Muted,
                    fontSize = 12.sp,
                )
                Action("LOCK NOW", vm::lock)
            }
        }
    }
}

@Composable
fun AuditScreen(s: RaceState) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
    ) {
        item {
            Heading("AUDIT TRAIL", size = 34)
            Text("Append-only • department scoped • hash chained", color = Muted, fontSize = 12.sp)
        }
        items(s.audit) { e ->
            RaceCard {
                Tag(e["role"].asString)
                Heading(e["action"].asString.replace('_', ' '), size = 19)
                Text(e["created_at"].asString, color = Muted, fontSize = 11.sp)
                Text("Actor ${e["actor_id"].asString.take(8)}…", fontSize = 11.sp)
                e["reason"]
                    .takeUnless { it.isJsonNull }
                    ?.let { Text(it.asString, fontSize = 12.sp) }
                Text("Hash ${e["event_hash"].asString.take(16)}…", fontSize = 9.sp, color = Muted)
            }
        }
    }
}
