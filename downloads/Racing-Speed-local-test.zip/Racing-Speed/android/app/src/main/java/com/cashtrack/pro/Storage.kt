package com.cashtrack.pro

import android.app.Application
import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.room.*
import dagger.hilt.android.HiltAndroidApp
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlinx.coroutines.flow.Flow
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory

@HiltAndroidApp class RacingApp : Application()

class Vault(context: Context) {
    private val prefs = context.getSharedPreferences("sealed", Context.MODE_PRIVATE)
    private val store by lazy { KeyStore.getInstance("AndroidKeyStore").apply { load(null) } }

    private fun key(): SecretKey {
        if (!store.containsAlias("cache-seal")) {
            KeyGenerator.getInstance("AES", "AndroidKeyStore").apply {
                init(
                    KeyGenParameterSpec.Builder(
                            "cache-seal",
                            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
                        )
                        .setBlockModes("GCM")
                        .setEncryptionPaddings("NoPadding")
                        .build()
                )
                generateKey()
            }
        }
        return store.getKey("cache-seal", null) as SecretKey
    }

    fun write(name: String, value: String) {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        prefs
            .edit()
            .putString(
                name,
                Base64.encodeToString(c.iv + c.doFinal(value.toByteArray()), Base64.NO_WRAP),
            )
            .apply()
    }

    fun remove(name: String) {
        prefs.edit().remove(name).apply()
    }

    fun read(name: String): String? {
        val bytes =
            prefs.getString(name, null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return null
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
            String(c.doFinal(bytes.copyOfRange(12, bytes.size)))
        } catch (_: Exception) {
            null
        }
    }

    fun cacheKey(): ByteArray {
        val existing = read("db-key")
        if (existing != null) return Base64.decode(existing, Base64.NO_WRAP)
        return ByteArray(32).also {
            SecureRandom().nextBytes(it)
            write("db-key", Base64.encodeToString(it, Base64.NO_WRAP))
        }
    }
}

@Entity(tableName = "collection_drafts")
data class CollectionDraft(
    @PrimaryKey val id: String,
    val ownerId: String,
    val customer: String,
    val amount: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Dao
interface DraftDao {
    @Query("SELECT * FROM collection_drafts WHERE ownerId=:owner ORDER BY createdAt")
    fun observe(owner: String): Flow<List<CollectionDraft>>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(draft: CollectionDraft)

    @Query("DELETE FROM collection_drafts WHERE id=:id AND ownerId=:owner")
    suspend fun remove(id: String, owner: String)
}

@Database(entities = [CollectionDraft::class], version = 1, exportSchema = false)
abstract class DraftDb : RoomDatabase() {
    abstract fun drafts(): DraftDao

    companion object {
        fun open(context: Context): DraftDb {
            System.loadLibrary("sqlcipher")
            return Room.databaseBuilder(context, DraftDb::class.java, "drafts.db")
                .openHelperFactory(SupportOpenHelperFactory(Vault(context).cacheKey()))
                .build()
        }
    }
}
